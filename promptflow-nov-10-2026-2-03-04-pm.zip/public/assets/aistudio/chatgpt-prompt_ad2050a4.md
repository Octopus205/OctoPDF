# OctoPDF: ChatGPT Build Prompt

You are a senior Android engineer with deep expertise in Kotlin, Jetpack Compose, Material 3, PDF rendering, and Android multi-window support. Build a complete, production-quality Android project called **OctoPDF**, an offline PDF viewer and editor for phones and tablets. Work through it step by step and explain each step briefly before writing the code.

## 1. Compatibility and build configuration

- `minSdk = 26` (Android 8.0), with `targetSdk` and `compileSdk` set to the latest stable version.
- Supported ABIs: `armeabi-v7a` (32-bit ARM) and `arm64-v8a` (64-bit ARM). Configure `ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }` and split APKs or App Bundle ABI splits accordingly.
- Use Kotlin, Gradle Kotlin DSL (`build.gradle.kts`), and a version catalog (`libs.versions.toml`).
- The app must work fully offline. Do not request the `INTERNET` permission.
- It must run on both phones and tablets, with adaptive layouts (use WindowSizeClass).

## 2. Core features

- **Multi-document tabs:** open several PDFs at once, each in its own tab. Users can switch between tabs by tapping or swiping, similar to Xodo. Closing a tab should ask to save unsaved changes. Tabs should persist across configuration changes.
- **Split screen:** view two PDFs side by side inside the same window, or two tabs at once. Support Android multi-window and tablet landscape mode. Each pane should have its own zoom and scroll position.
- **Viewer:** continuous vertical scrolling, pinch-to-zoom, a page thumbnail sidebar, full-text search with result highlighting, bookmarks, night/sepia/light reading modes, and remembering the last read page per file.
- **Editor:** highlight, underline, strikethrough, freehand drawing with color and thickness options, text notes, shapes (rectangle, ellipse, arrow), signature capture, image stamps, and undo/redo.
- **Page management:** rotate, delete, reorder, and insert pages.
- **Save behavior:** "Save" overwrites the file, and "Save as copy" writes a new file without changing the original.
- **Tools:** merge multiple PDFs, split a PDF into separate files, extract selected pages, and add or remove password protection.
- **File management:** recent files, favorites, and opening files through the Storage Access Framework (`ACTION_OPEN_DOCUMENT`). Also support opening PDFs shared from other apps via intent filters.

## 3. Technical choices

- Recommend and justify a PDF rendering engine for Android. Options include PdfiumAndroid (Apache 2.0), AndroidPdfViewer, and the framework `PdfRenderer` (API 21+, view-only, so editing needs another library). Explain the tradeoffs, including licensing. Avoid AGPL-licensed libraries such as MuPDF unless you clearly flag the licensing impact.
- For editing and page operations, recommend a library such as PdfBox-Android or iText (check the license, since iText's open-source version is AGPL).
- Use Coroutines and Flow, a ViewModel per screen, and a clean architecture (UI, domain, and data layers).
- Render pages on background threads, cache bitmaps with LruCache, and keep memory usage low on older devices with 2 GB of RAM.
- Store recent files, bookmarks, and reading positions in Room or DataStore.

## 4. Design

- Material 3 with Dynamic Color support on Android 12 and above, and a clean fallback palette for older versions.
- Full RTL support and Arabic localization (strings in `values-ar`).
- The tablet layout uses a navigation rail or side panel for file lists and thumbnails.
- Use a clear, minimal toolbar, with editing tools in a bottom sheet or floating toolbar.
- App icon: `docs/octopdf-icon.svg`, an octopus merged with a PDF page (red octopus on a white page, blue background). Generate the adaptive icon (foreground and background layers) for `mipmap` and `drawable` resources.

## 5. Project deliverables

- Full project structure, including `settings.gradle.kts`, `build.gradle.kts` files, an `AndroidManifest.xml` with the necessary intent filters, and resource files.
- The most important classes and screens with complete code: the tab manager, split-screen container, PDF viewer composable, annotation layer, and file repository.
- Unit tests for the core logic (tab state, document repository), and a few UI tests for tab switching and split-screen mode.
- A `.gitignore` for Android projects and a `LICENSE` placeholder.
- List every Android permission needed, and explain why each is required.

## 6. Output format

- Start with a short architecture overview.
- Then go file by file, with the file path as a heading before each code block.
- Keep explanations brief and focused on decisions that matter.
- End with a list of known limitations and suggested next steps.
