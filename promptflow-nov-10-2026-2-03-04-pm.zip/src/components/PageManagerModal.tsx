import React from 'react';
import { 
  RotateCw, 
  RotateCcw, 
  Trash2, 
  Copy, 
  ArrowUp, 
  ArrowDown, 
  X, 
  LayoutGrid,
  Check
} from 'lucide-react';
import { TRANSLATIONS } from '../data/translations';
import { AppLanguage, PdfDocument } from '../types/pdf';

interface PageManagerModalProps {
  isOpen: boolean;
  doc: PdfDocument;
  onClose: () => void;
  onRotatePage: (pageIndex: number, degrees: number) => void;
  onDeletePage: (pageIndex: number) => void;
  onDuplicatePage: (pageIndex: number) => void;
  onMovePage: (fromIndex: number, toIndex: number) => void;
  lang: AppLanguage;
}

export const PageManagerModal: React.FC<PageManagerModalProps> = ({
  isOpen,
  doc,
  onClose,
  onRotatePage,
  onDeletePage,
  onDuplicatePage,
  onMovePage,
  lang,
}) => {
  if (!isOpen) return null;
  const t = TRANSLATIONS[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
              <LayoutGrid className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-slate-100">{t.pageManager}</h3>
              <p className="text-xs text-slate-400">{doc.name} • {doc.pages.length} {t.page}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Page Grid */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {doc.pages.map((page, idx) => (
              <div 
                key={`${page.index}-${idx}`}
                className="bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-xl p-3 flex flex-col gap-3 group transition"
              >
                {/* Visual Thumbnail */}
                <div className="relative aspect-[3/4] bg-white rounded-lg p-3 text-slate-900 overflow-hidden shadow-sm flex flex-col justify-between"
                  style={{
                    transform: `rotate(${page.rotation}deg)`,
                    transition: 'transform 0.2s ease-in-out'
                  }}
                >
                  <div className="space-y-1">
                    <div className="h-2 w-16 bg-slate-300 rounded" />
                    <div className="h-1.5 w-full bg-slate-200 rounded" />
                    <div className="h-1.5 w-4/5 bg-slate-200 rounded" />
                    <div className="h-1.5 w-full bg-slate-200 rounded" />
                  </div>
                  <div className="text-[10px] font-semibold text-slate-700 truncate">
                    {page.title}
                  </div>
                  <div className="text-[9px] text-slate-400 self-end">
                    {idx + 1}
                  </div>

                  {page.rotation > 0 && (
                    <div className="absolute top-1 right-1 px-1.5 py-0.5 bg-rose-600 text-white text-[9px] font-bold rounded">
                      {page.rotation}°
                    </div>
                  )}
                </div>

                {/* Page Info & Actions */}
                <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                  <span className="font-medium text-slate-200">{t.page} {idx + 1}</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onMovePage(idx, idx - 1)}
                      disabled={idx === 0}
                      title={t.moveUp}
                      className="p-1 hover:bg-slate-800 rounded disabled:opacity-30 disabled:hover:bg-transparent"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onMovePage(idx, idx + 1)}
                      disabled={idx === doc.pages.length - 1}
                      title={t.moveDown}
                      className="p-1 hover:bg-slate-800 rounded disabled:opacity-30 disabled:hover:bg-transparent"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Operations Bar */}
                <div className="grid grid-cols-4 gap-1 pt-1 border-t border-slate-800/80">
                  <button
                    onClick={() => onRotatePage(idx, 90)}
                    title={t.rotateClockwise}
                    className="p-1.5 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onRotatePage(idx, -90)}
                    title={t.rotateCounterClockwise}
                    className="p-1.5 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDuplicatePage(idx)}
                    title={t.duplicatePage}
                    className="p-1.5 flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeletePage(idx)}
                    disabled={doc.pages.length <= 1}
                    title={t.deletePage}
                    className="p-1.5 flex items-center justify-center text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg disabled:opacity-30 disabled:hover:bg-transparent transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            {doc.pages.length} pages total • Edits are marked as unsaved
          </span>
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-5 py-2 text-sm font-medium bg-rose-600 hover:bg-rose-500 text-white rounded-xl transition"
          >
            <Check className="w-4 h-4" />
            {t.apply}
          </button>
        </div>
      </div>
    </div>
  );
};
