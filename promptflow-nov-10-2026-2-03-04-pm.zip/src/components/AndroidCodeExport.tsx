import React, { useState } from 'react';
import { 
  Folder, 
  FileCode, 
  Download, 
  Copy, 
  Check, 
  BookOpen, 
  ShieldCheck, 
  Cpu, 
  Layers,
  ChevronRight,
  Code2
} from 'lucide-react';
import { ANDROID_PROJECT_FILES, AndroidProjectFile } from '../data/androidProjectFiles';
import { downloadAndroidProjectZip } from '../utils/zipExporter';
import { TRANSLATIONS } from '../data/translations';
import { AppLanguage } from '../types/pdf';

interface AndroidCodeExportProps {
  lang: AppLanguage;
}

type TabMode = 'files' | 'architecture' | 'permissions';

export const AndroidCodeExport: React.FC<AndroidCodeExportProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];
  const [activeTab, setActiveTab] = useState<TabMode>('files');
  const [selectedFile, setSelectedFile] = useState<AndroidProjectFile>(ANDROID_PROJECT_FILES[3]); // app/build.gradle.kts default
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } catch (e) {
      console.error(e);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-slate-100 overflow-hidden">
      {/* Top Bar */}
      <div className="h-14 border-b border-slate-800 bg-slate-900 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
            <Code2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-semibold text-sm text-slate-100">OctoPDF Android Studio Workspace</h2>
            <p className="text-[11px] text-slate-400">Kotlin 2.1.0 • Jetpack Compose BOM • Pdfium & PDFBox (Apache 2.0)</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Sub-tabs */}
          <div className="flex bg-slate-800/80 p-1 rounded-xl border border-slate-700">
            <button
              onClick={() => setActiveTab('files')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition ${
                activeTab === 'files' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              Source Files ({ANDROID_PROJECT_FILES.length})
            </button>
            <button
              onClick={() => setActiveTab('architecture')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition ${
                activeTab === 'architecture' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              PDF Engine & Licenses
            </button>
            <button
              onClick={() => setActiveTab('permissions')}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-lg transition ${
                activeTab === 'permissions' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Permissions Matrix
            </button>
          </div>

          {/* Download ZIP */}
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold rounded-xl transition shadow-lg shadow-emerald-950/40"
          >
            <Download className="w-4 h-4" />
            {isZipping ? 'Bundling ZIP...' : t.downloadAndroidZip}
          </button>
        </div>
      </div>

      {/* Main View Area */}
      {activeTab === 'files' && (
        <div className="flex-1 flex overflow-hidden">
          {/* Left: Android Project File Tree */}
          <div className="w-72 border-r border-slate-800 bg-slate-900/60 flex flex-col overflow-y-auto">
            <div className="p-3 text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center justify-between border-b border-slate-800">
              <span className="flex items-center gap-1.5">
                <Folder className="w-3.5 h-3.5 text-amber-400" /> Project Structure
              </span>
              <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">
                {ANDROID_PROJECT_FILES.length} files
              </span>
            </div>
            <div className="p-2 space-y-0.5">
              {ANDROID_PROJECT_FILES.map((file) => {
                const isSelected = selectedFile.path === file.path;
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center gap-2 transition ${
                      isSelected
                        ? 'bg-rose-600/20 text-rose-300 font-medium border border-rose-500/30'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-rose-400' : 'text-slate-500'}`} />
                    <span className="truncate">{file.path}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Code Viewer */}
          <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
            {/* File info bar */}
            <div className="h-10 border-b border-slate-800 bg-slate-900/40 px-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs">
                <span className="font-mono text-slate-200">{selectedFile.path}</span>
                <span className="text-[10px] text-slate-500">• {selectedFile.description}</span>
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied!' : 'Copy Code'}
              </button>
            </div>

            {/* Code Content */}
            <div className="flex-1 overflow-auto p-4 bg-slate-950">
              <pre className="font-mono text-xs leading-relaxed text-slate-300 selection:bg-rose-900/60 selection:text-white">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Engine & Licensing Guide Tab */}
      {activeTab === 'architecture' && (
        <div className="flex-1 overflow-y-auto p-8 max-w-5xl mx-auto space-y-8">
          <div className="space-y-2">
            <h3 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <Cpu className="w-6 h-6 text-rose-500" />
              Android PDF Engine Evaluation & Licensing Strategy
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Detailed technical justifications for OctoPDF's rendering stack, memory optimization on 2GB RAM devices, and enterprise licensing compliance.
            </p>
          </div>

          {/* Engine Comparison Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-slate-100 text-sm">1. PdfiumAndroid (Selected for Rendering)</h4>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full">
                  Apache 2.0 • Recommended
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Native C++ port of the Google Chrome / Foxit PDF rendering engine. Compiles directly into high-speed ARM binaries (<code>armeabi-v7a</code>, <code>arm64-v8a</code>). Provides anti-aliased font rasterization, smooth pinch-to-zoom at 60 FPS, and rapid tile-based rendering.
              </p>
              <div className="text-[11px] text-slate-400 space-y-1">
                <div>✓ <strong>Pros:</strong> High fidelity, fast native C++ execution, 100% Apache 2.0 enterprise license.</div>
                <div>⚠ <strong>Trade-off:</strong> Adds ~5–8MB native library weight (mitigated via Gradle ABI splits).</div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-slate-100 text-sm">2. Apache PDFBox-Android (Selected for Editing)</h4>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full">
                  Apache 2.0 • Recommended
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Java/Kotlin-compatible port of Apache PDFBox. Used for non-visual operations: merging multi-document files, splitting page ranges, extracting text for search highlighting, and writing standard PDF annotation streams back to disk.
              </p>
              <div className="text-[11px] text-slate-400 space-y-1">
                <div>✓ <strong>Pros:</strong> Robust document manipulation, password encryption, zero native dependency.</div>
                <div>⚠ <strong>Trade-off:</strong> Slower rasterizer than Pdfium (which is why OctoPDF pairs both engines).</div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-700 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-slate-100 text-sm">3. Android Framework PdfRenderer (API 21+)</h4>
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 text-[10px] font-bold rounded-full">
                  AOSP Built-in • View Only
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                The framework <code>android.graphics.pdf.PdfRenderer</code> has 0 KB APK overhead because it is built directly into Android.
              </p>
              <div className="text-[11px] text-slate-400 space-y-1">
                <div>✓ <strong>Pros:</strong> Zero app size increase, simple memory footprint.</div>
                <div>✕ <strong>Cons:</strong> View-only rasterizer. Does not support text search, metadata extraction, or modifying/saving annotations.</div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-rose-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold text-slate-100 text-sm">4. MuPDF & iText (License Flagged)</h4>
                <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 text-[10px] font-bold rounded-full">
                  AGPL v3 • Warning
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Both MuPDF and iText open-source editions are licensed under the GNU Affero General Public License (AGPLv3).
              </p>
              <div className="text-[11px] text-slate-400 space-y-1">
                <div>⚠ <strong>Legal Impact:</strong> Using AGPL libraries requires either open-sourcing the entire application source code or purchasing costly commercial licenses. OctoPDF strictly selects Apache 2.0 alternatives to avoid licensing traps.</div>
              </div>
            </div>
          </div>

          {/* Memory Management on 2GB RAM Devices */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h4 className="text-base font-semibold text-slate-100 flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              Memory Safeguards for 2GB RAM Devices
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300">
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">1. Dynamic LruCache Sizing</div>
                <p className="text-slate-400 leading-relaxed">
                  The bitmap cache dynamically limits itself to <code>Runtime.getRuntime().maxMemory() / 8</code> (typically 24–32MB on low-memory devices), guaranteeing zero memory contention with Android system UI.
                </p>
              </div>
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">2. Bitmap Recycling & inBitmap</div>
                <p className="text-slate-400 leading-relaxed">
                  Offscreen page bitmaps are promptly marked for reuse with <code>BitmapFactory.Options.inBitmap</code>, avoiding GC pauses and allocation thrashing during fast document scrolling.
                </p>
              </div>
              <div className="p-4 bg-slate-950/60 rounded-xl border border-slate-800 space-y-2">
                <div className="font-semibold text-slate-200">3. Tiled Viewport Rendering</div>
                <p className="text-slate-400 leading-relaxed">
                  High-DPI pages are only rasterized for the viewport rect currently visible on screen. Thumbnails are rendered at 1/4 resolution (RGB_565), cutting memory by 75%.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Permissions Matrix Tab */}
      {activeTab === 'permissions' && (
        <div className="flex-1 overflow-y-auto p-8 max-w-4xl mx-auto space-y-6">
          <div className="space-y-2">
            <h3 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
              Android Permissions Audit & Privacy Architecture
            </h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              OctoPDF is designed as an air-gapped offline utility. Here is the strict verification of all permissions requested in <code>AndroidManifest.xml</code>:
            </p>
          </div>

          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/60">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Permission Name</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Max SDK</th>
                  <th className="py-3 px-4">Rationale & Compliance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                <tr className="bg-rose-950/20">
                  <td className="py-3 px-4 font-mono font-semibold text-rose-300">
                    android.permission.INTERNET
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 font-bold rounded-full">
                      OMITTED / FORBIDDEN
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">—</td>
                  <td className="py-3 px-4 text-slate-300">
                    The app NEVER requests network access. No telemetry, no external ad SDKs, no cloud tracking. Complete offline privacy.
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-mono text-slate-200">
                    android.permission.READ_EXTERNAL_STORAGE
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 font-bold rounded-full">
                      Scoped
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">maxSdkVersion="32"</td>
                  <td className="py-3 px-4 text-slate-300">
                    Required only for backward compatibility on Android 8.0–12 devices when opening PDF files from shared folders. On Android 13+, Scoped Storage Access Framework (SAF) is used instead.
                  </td>
                </tr>

                <tr>
                  <td className="py-3 px-4 font-mono text-slate-200">
                    android.permission.WRITE_EXTERNAL_STORAGE
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 font-bold rounded-full">
                      Legacy Scoped
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400">maxSdkVersion="28"</td>
                  <td className="py-3 px-4 text-slate-300">
                    Restricted strictly to Android 9 (API 28) and below. Modern Android uses <code>ACTION_CREATE_DOCUMENT</code> via SAF to write files without requiring blanket disk write permissions.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 leading-relaxed">
            <span className="font-semibold text-slate-200">Storage Access Framework (SAF) Notice:</span> Documents are accessed through content URIs (<code>content://...</code>) via <code>ACTION_OPEN_DOCUMENT</code> and persisted securely via <code>takePersistableUriPermission()</code>, conforming to Google Play Scoped Storage policies.
          </div>
        </div>
      )}
    </div>
  );
};
