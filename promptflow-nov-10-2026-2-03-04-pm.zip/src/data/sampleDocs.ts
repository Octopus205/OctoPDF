import { PdfDocument } from '../types/pdf';

export const INITIAL_DOCUMENTS: PdfDocument[] = [
  {
    id: 'doc-octopdf-guide',
    name: 'OctoPDF_User_Guide.pdf',
    sizeBytes: 1024 * 480, // 480 KB
    totalPages: 5,
    lastReadPage: 0,
    lastModified: Date.now() - 3600000 * 2,
    isFavorite: true,
    isPasswordProtected: false,
    isModified: false,
    bookmarks: [
      { id: 'bm-1', pageIndex: 0, title: 'Introduction & Mission', createdAt: Date.now() - 3600000 },
      { id: 'bm-2', pageIndex: 1, title: 'Multi-Document & Split-Screen', createdAt: Date.now() - 3500000 },
      { id: 'bm-3', pageIndex: 2, title: 'Offline Security & Architecture', createdAt: Date.now() - 3400000 },
    ],
    pages: [
      {
        index: 0,
        title: 'Overview & Key Capabilities',
        rotation: 0,
        annotations: [],
        content: [
          '# OctoPDF: Modern Offline PDF Studio',
          'OctoPDF is designed as an ultra-responsive, privacy-focused offline PDF viewer and annotation workstation for modern Android devices and professional tablets.',
          'Key Architectural Pillars:',
          '• Zero Internet Requirement: Does not request the android.permission.INTERNET permission, ensuring 100% air-gapped security and confidentiality for sensitive documents.',
          '• Multi-Window & Adaptive Layouts: Seamlessly transitions between phone bottom-sheet workflows and tablet navigation rails with dual-pane split-screen rendering.',
          '• Native C++ High-Performance Rendering: Designed around PdfiumAndroid and Apache PDFBox with strict LruCache bitmap pooling for low-memory (2GB RAM) resilience.'
        ]
      },
      {
        index: 1,
        title: 'Multi-Tab & Split-Screen Navigation',
        rotation: 0,
        annotations: [],
        content: [
          '# Chapter 1: Multi-Document Workspaces',
          'OctoPDF supports opening multiple PDF documents in concurrent tabs, similar to desktop workstations and Xodo.',
          'Split-Screen Pane Features:',
          '1. Dual Pane Side-by-Side: View contract revisions or reference manuals side-by-side on tablet landscape mode or foldable devices.',
          '2. Independent State Management: Each viewport retains its own zoom level, pan coordinates, active page index, and search query.',
          '3. Unsaved Work Safeguards: If annotations or rotated pages remain unsaved, closing a tab prompts the user with Save, Save as Copy, or Discard actions.'
        ]
      },
      {
        index: 2,
        title: 'Annotation & Signature Engine',
        rotation: 0,
        annotations: [],
        content: [
          '# Chapter 2: Comprehensive Annotation Suite',
          'Annotate any document directly on top of the vector rendering canvas with hardware-accelerated drawing:',
          '• Freehand Pen & Highlighters: Variable stroke widths with alpha blending for legible text highlighting.',
          '• Geometry & Vector Shapes: Precision rectangles, ellipses, callout arrows, and text notes.',
          '• Signature & Stamp Capture: Draw or import digital signatures and place them anywhere on the page.',
          '• Full Undo / Redo: Reversible mutation stack allowing quick correction of markup.'
        ]
      },
      {
        index: 3,
        title: 'Page Manipulation & PDF Operations',
        rotation: 0,
        annotations: [],
        content: [
          '# Chapter 3: Page Organization & File Operations',
          'Manage complex multi-page documents without external cloud utilities:',
          '• Real-time Page Rotation: Rotate clockwise or counter-clockwise in 90-degree increments.',
          '• Reorder & Delete: Drag or move pages up/down, remove redundant pages, or insert clean blank sheets.',
          '• PDF Tools Engine: Merge multiple separate PDF files into a single master document, split pages into distinct files, or extract specific page ranges.'
        ]
      },
      {
        index: 4,
        title: 'Offline Storage & Android SAF Integration',
        rotation: 0,
        annotations: [],
        content: [
          '# Chapter 4: Storage Access Framework & Room DB',
          'OctoPDF integrates with Android Storage Access Framework (SAF) via ACTION_OPEN_DOCUMENT and ACTION_CREATE_DOCUMENT.',
          'Persistent metadata—including reading progress, bookmarks, and recent file records—is maintained in a local Room database with AES encryption support.'
        ]
      }
    ]
  },
  {
    id: 'doc-android-ndk',
    name: 'Android_NDK_and_Pdfium_Architecture.pdf',
    sizeBytes: 1024 * 720, // 720 KB
    totalPages: 4,
    lastReadPage: 1,
    lastModified: Date.now() - 3600000 * 5,
    isFavorite: true,
    isPasswordProtected: false,
    isModified: false,
    bookmarks: [
      { id: 'bm-ndk-1', pageIndex: 0, title: 'Pdfium vs Framework PdfRenderer', createdAt: Date.now() - 7200000 },
      { id: 'bm-ndk-2', pageIndex: 1, title: 'LruCache & Low Memory Safeguards', createdAt: Date.now() - 7100000 }
    ],
    pages: [
      {
        index: 0,
        title: 'Engine Comparison & Licensing',
        rotation: 0,
        annotations: [],
        content: [
          '# Android PDF Engine Trade-off Analysis',
          'Selecting the right PDF rendering and manipulation stack is vital for production Android apps:',
          '1. PdfiumAndroid (Apache 2.0): High-fidelity C++ Foxit/Google engine port. Supports smooth zooming, anti-aliased font rendering, and fast tile rendering.',
          '2. Android Framework PdfRenderer (API 21+): Native system component with zero APK size overhead, but strictly view-only with no text search or annotation authoring.',
          '3. Apache PDFBox-Android (Apache 2.0): Essential for non-visual operations like merging, splitting, extracting text, and writing standard PDF annotation streams.',
          '4. MuPDF & iText (AGPL Caution): Both enforce copyleft requirements under AGPLv3. OctoPDF strictly selects Apache 2.0 alternatives to protect enterprise IP.'
        ]
      },
      {
        index: 1,
        title: 'ABI Splits & NDK Optimization',
        rotation: 0,
        annotations: [],
        content: [
          '# ABI Target Architecture',
          'To optimize APK download size and run on 99.8% of modern Android hardware:',
          '• arm64-v8a: Primary 64-bit target for high-performance tablet rendering with NEON vectorization.',
          '• armeabi-v7a: 32-bit legacy fallback for budget devices.',
          'Gradle Configuration:',
          'ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }',
          'Split APKs or Google Play App Bundle dynamic delivery reduces installed package size by up to 60% compared to fat universal binaries.'
        ]
      },
      {
        index: 2,
        title: 'Memory Management on 2GB RAM Devices',
        rotation: 0,
        annotations: [],
        content: [
          '# Bitmap Recycling & LruCache Strategy',
          'Rendering full-resolution A4 pages at 300 DPI generates ~8.5MB per uncompressed ARGB_8888 bitmap.',
          'To prevent OutOfMemory (OOM) crashes on 2GB RAM devices:',
          '1. LruCache sized dynamically to 1/8th of available runtime heap.',
          '2. Tiled rendering: Render low-res preview thumbnail first, followed by viewport-visible tiles.',
          '3. Immediate Bitmap recycling via inBitmap options when navigating pages.'
        ]
      },
      {
        index: 3,
        title: 'Jetpack Compose & Material 3 Adaptive UI',
        rotation: 0,
        annotations: [],
        content: [
          '# Adaptive UI with WindowSizeClass',
          '• Compact (Phones): Bottom navigation, collapsible bottom sheets for annotation tools, vertical single-document stream.',
          '• Expanded (Tablets & Foldables): Persistent Navigation Rail, dual-pane split-screen container, floating quick-action toolbar, and thumbnail drawer.'
        ]
      }
    ]
  },
  {
    id: 'doc-arabic-contract',
    name: 'عقد_الخدمات_التقنية_المعتمد.pdf',
    sizeBytes: 1024 * 310, // 310 KB
    totalPages: 3,
    lastReadPage: 0,
    lastModified: Date.now() - 3600000 * 24,
    isFavorite: false,
    isPasswordProtected: false,
    isModified: false,
    bookmarks: [
      { id: 'bm-ar-1', pageIndex: 0, title: 'الديباجة والأطراف', createdAt: Date.now() - 86400000 },
      { id: 'bm-ar-2', pageIndex: 1, title: 'نطاق العمل والسرية', createdAt: Date.now() - 86300000 }
    ],
    pages: [
      {
        index: 0,
        title: 'وثيقة رسمية: عقد اتفاقية تطوير',
        rotation: 0,
        annotations: [],
        content: [
          '# وثيقة رسمية: عقد تقديم خدمات برمجية وتطوير النظم',
          'تم إبرام هذا العقد في يوم الثلاثاء بين كل من:',
          'الطرف الأول: شركة التطوير الهندسي للبرمجيات الذكية (Octo Systems).',
          'الطرف الثاني: المؤسسة التقنية للاستشارات الرقمية وحلول الأعمال.',
          'البند الأول (الهدف من العقد):',
          'يلتزم الطرف الأول بتوفير بنية برمجية متكاملة لتطبيق OctoPDF لنظام أندرويد متوافق مع معايير Material 3 ودعم كامل للغة العربية والاتجاه من اليمين إلى اليسار (RTL).'
        ]
      },
      {
        index: 1,
        title: 'شروط الخصوصية والأمان بدون إنترنت',
        rotation: 0,
        annotations: [],
        content: [
          '# البند الثاني: معايير الأمان والعمل دون اتصال (Offline)',
          '1. يقر الطرفان بأن التطبيق لن يطلب صلاحية الوصول إلى شبكة الإنترنت (android.permission.INTERNET).',
          '2. تبقى كافة الوثائق والملفات والمستندات مخزنة محلياً داخل المساحة المخصصة للتطبيق أو عبر مزود الوصول إلى التخزين (Storage Access Framework).',
          '3. التوقيعات الرقمية والملاحظات المدونة تشفر وتدمج داخل طبقات ملف الـ PDF القياسي دون إرسال أي بايت لخوادم خارجية.'
        ]
      },
      {
        index: 2,
        title: 'التوقيعات والاعتماد النهائي',
        rotation: 0,
        annotations: [],
        content: [
          '# البند الثالث: التوقيع والإقرار النهائي',
          'بهذا يقر الطرفان باطلاعهما على كافة الشروط والمواصفات الفنية المرفقة، وقد جرى توقيع هذه النسخة إلكترونياً باستخدام أداة التوقيع الرقمي المدمجة في تطبيق OctoPDF.',
          'توقيع الطرف الأول: [تم التوثيق الرقمي]',
          'توقيع الطرف الثاني: [في انتظار التوقيع المعتمد]'
        ]
      }
    ]
  }
];
