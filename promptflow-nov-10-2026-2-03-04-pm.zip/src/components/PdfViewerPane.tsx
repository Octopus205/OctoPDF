import React, { useState, useRef, useEffect } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Sun, 
  Moon, 
  Coffee, 
  Search, 
  ChevronUp, 
  ChevronDown, 
  Bookmark, 
  BookmarkCheck, 
  LayoutList, 
  PenTool, 
  Highlighter, 
  Underline as UnderlineIcon, 
  Strikethrough as StrikethroughIcon, 
  Square, 
  Circle, 
  ArrowRight, 
  MessageSquare, 
  Eraser, 
  Undo, 
  Redo, 
  Save, 
  Download, 
  LayoutGrid, 
  X,
  FileSignature
} from 'lucide-react';
import { 
  PdfDocument, 
  PdfPage, 
  Annotation, 
  ActiveTool, 
  ReadingMode, 
  AppLanguage,
  DrawingAnnotation,
  ShapeAnnotation,
  NoteAnnotation,
  SignatureAnnotation,
  Point
} from '../types/pdf';
import { TRANSLATIONS } from '../data/translations';
import { SignatureModal } from './SignatureModal';
import { PageManagerModal } from './PageManagerModal';
import { exportDocumentToPdf } from '../utils/pdfGenerator';

interface PdfViewerPaneProps {
  doc: PdfDocument;
  onUpdateDoc: (updated: PdfDocument) => void;
  onSaveDoc: (doc: PdfDocument) => void;
  lang: AppLanguage;
  isCompact?: boolean;
}

export const PdfViewerPane: React.FC<PdfViewerPaneProps> = ({
  doc,
  onUpdateDoc,
  onSaveDoc,
  lang,
  isCompact = false,
}) => {
  const t = TRANSLATIONS[lang];

  // Viewer state
  const [zoom, setZoom] = useState(100);
  const [readingMode, setReadingMode] = useState<ReadingMode>('light');
  const [activeSidebar, setActiveSidebar] = useState<'thumbnails' | 'bookmarks' | null>(null);
  const [activePage, setActivePage] = useState(doc.lastReadPage || 0);

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);

  // Annotation Tool state
  const [activeTool, setActiveTool] = useState<ActiveTool>('select');
  const [activeColor, setActiveColor] = useState('#e11d48'); // Rose default
  const [activeStrokeWidth, setActiveStrokeWidth] = useState(3);
  const [isSignatureModalOpen, setIsSignatureModalOpen] = useState(false);
  const [isPageManagerOpen, setIsPageManagerOpen] = useState(false);

  // History stack for Undo / Redo
  const [undoStack, setUndoStack] = useState<PdfPage[][]>([]);
  const [redoStack, setRedoStack] = useState<PdfPage[][]>([]);

  // Drawing state
  const [isInteracting, setIsInteracting] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<Point[]>([]);
  const [shapeStart, setShapeStart] = useState<Point | null>(null);
  const [shapeEnd, setShapeEnd] = useState<Point | null>(null);
  const [activeNoteEditing, setActiveNoteEditing] = useState<{ pageIndex: number; annId: string } | null>(null);
  const [noteInputText, setNoteInputText] = useState('');

  const containerRef = useRef<HTMLDivElement | null>(null);
  const pageRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Push current pages state to undo stack before changes
  const recordHistory = () => {
    setUndoStack((prev) => [...prev.slice(-15), JSON.parse(JSON.stringify(doc.pages))]);
    setRedoStack([]);
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setRedoStack((prev) => [...prev, JSON.parse(JSON.stringify(doc.pages))]);
    setUndoStack((prev) => prev.slice(0, -1));

    const updated = {
      ...doc,
      pages: previous,
      isModified: true,
    };
    onUpdateDoc(updated);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setUndoStack((prev) => [...prev, JSON.parse(JSON.stringify(doc.pages))]);
    setRedoStack((prev) => prev.slice(0, -1));

    const updated = {
      ...doc,
      pages: next,
      isModified: true,
    };
    onUpdateDoc(updated);
  };

  // Scroll to active page
  const scrollToPage = (index: number) => {
    setActivePage(index);
    const targetElement = pageRefs.current[index];
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    // Update last read page
    if (doc.lastReadPage !== index) {
      onUpdateDoc({ ...doc, lastReadPage: index });
    }
  };

  // Search matching
  const searchMatches = React.useMemo(() => {
    if (!searchQuery.trim()) return [];
    const query = searchQuery.toLowerCase();
    const matches: { pageIndex: number; text: string }[] = [];

    doc.pages.forEach((page, pIdx) => {
      page.content.forEach((line) => {
        if (line.toLowerCase().includes(query)) {
          matches.push({ pageIndex: pIdx, text: line });
        }
      });
    });
    return matches;
  }, [searchQuery, doc.pages]);

  const handleNextMatch = () => {
    if (searchMatches.length === 0) return;
    const nextIndex = (currentMatchIndex + 1) % searchMatches.length;
    setCurrentMatchIndex(nextIndex);
    scrollToPage(searchMatches[nextIndex].pageIndex);
  };

  const handlePrevMatch = () => {
    if (searchMatches.length === 0) return;
    const prevIndex = (currentMatchIndex - 1 + searchMatches.length) % searchMatches.length;
    setCurrentMatchIndex(prevIndex);
    scrollToPage(searchMatches[prevIndex].pageIndex);
  };

  // Bookmarks toggle
  const isPageBookmarked = doc.bookmarks.some((b) => b.pageIndex === activePage);

  const toggleBookmark = () => {
    recordHistory();
    let updatedBookmarks = [...doc.bookmarks];
    if (isPageBookmarked) {
      updatedBookmarks = updatedBookmarks.filter((b) => b.pageIndex !== activePage);
    } else {
      updatedBookmarks.push({
        id: `bm-${Date.now()}`,
        pageIndex: activePage,
        title: doc.pages[activePage]?.title || `Page ${activePage + 1}`,
        createdAt: Date.now(),
      });
    }
    onUpdateDoc({ ...doc, bookmarks: updatedBookmarks, isModified: true });
  };

  // Drawing interactions on page
  const handlePageMouseDown = (pIdx: number, e: React.MouseEvent<HTMLDivElement>) => {
    if (activeTool === 'select') return;
    const rect = e.currentTarget.getBoundingClientRect();
    const point: Point = {
      x: (e.clientX - rect.left) / (zoom / 100),
      y: (e.clientY - rect.top) / (zoom / 100),
    };

    if (activeTool === 'pen' || activeTool === 'highlight') {
      setIsInteracting(true);
      setCurrentStroke([point]);
    } else if (activeTool === 'rect' || activeTool === 'ellipse' || activeTool === 'arrow') {
      setIsInteracting(true);
      setShapeStart(point);
      setShapeEnd(point);
    } else if (activeTool === 'note') {
      recordHistory();
      const newNote: NoteAnnotation = {
        id: `note-${Date.now()}`,
        pageIndex: pIdx,
        type: 'note',
        color: '#fef08a', // pale yellow
        createdAt: Date.now(),
        position: point,
        text: 'Type your note here...',
        author: 'User',
      };
      const updatedPages = [...doc.pages];
      updatedPages[pIdx].annotations.push(newNote);
      onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
      setActiveNoteEditing({ pageIndex: pIdx, annId: newNote.id });
      setNoteInputText(newNote.text);
      setActiveTool('select');
    }
  };

  const handlePageMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isInteracting) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const point: Point = {
      x: (e.clientX - rect.left) / (zoom / 100),
      y: (e.clientY - rect.top) / (zoom / 100),
    };

    if (activeTool === 'pen' || activeTool === 'highlight') {
      setCurrentStroke((prev) => [...prev, point]);
    } else if (activeTool === 'rect' || activeTool === 'ellipse' || activeTool === 'arrow') {
      setShapeEnd(point);
    }
  };

  const handlePageMouseUp = (pIdx: number) => {
    if (!isInteracting) return;
    setIsInteracting(false);

    if ((activeTool === 'pen' || activeTool === 'highlight') && currentStroke.length > 1) {
      recordHistory();
      const newAnn: DrawingAnnotation = {
        id: `draw-${Date.now()}`,
        pageIndex: pIdx,
        type: activeTool,
        color: activeColor,
        strokeWidth: activeTool === 'highlight' ? 14 : activeStrokeWidth,
        opacity: activeTool === 'highlight' ? 0.35 : 1,
        points: currentStroke,
        createdAt: Date.now(),
      };
      const updatedPages = [...doc.pages];
      updatedPages[pIdx].annotations.push(newAnn);
      onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
      setCurrentStroke([]);
    } else if ((activeTool === 'rect' || activeTool === 'ellipse' || activeTool === 'arrow') && shapeStart && shapeEnd) {
      recordHistory();
      const newShape: ShapeAnnotation = {
        id: `shape-${Date.now()}`,
        pageIndex: pIdx,
        type: activeTool,
        color: activeColor,
        strokeWidth: activeStrokeWidth,
        start: shapeStart,
        end: shapeEnd,
        createdAt: Date.now(),
      };
      const updatedPages = [...doc.pages];
      updatedPages[pIdx].annotations.push(newShape);
      onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
      setShapeStart(null);
      setShapeEnd(null);
    }
  };

  const insertSignatureOnPage = (dataUrl: string) => {
    recordHistory();
    const targetPageIndex = activePage;
    const newSig: SignatureAnnotation = {
      id: `sig-${Date.now()}`,
      pageIndex: targetPageIndex,
      type: 'signature',
      color: '#000000',
      createdAt: Date.now(),
      position: { x: 120, y: 350 },
      width: 180,
      height: 80,
      dataUrl,
    };
    const updatedPages = [...doc.pages];
    updatedPages[targetPageIndex].annotations.push(newSig);
    onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
    setActiveTool('select');
  };

  // Color theme styles
  const themeClasses = {
    light: {
      bg: 'bg-slate-900',
      page: 'bg-white text-slate-900 shadow-xl',
      border: 'border-slate-300',
    },
    sepia: {
      bg: 'bg-[#292524]',
      page: 'bg-[#fef9c3] text-[#422006] shadow-xl',
      border: 'border-[#fde047]',
    },
    night: {
      bg: 'bg-slate-950',
      page: 'bg-slate-900 text-slate-100 shadow-xl border border-slate-800',
      border: 'border-slate-700',
    },
  }[readingMode];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden relative">
      {/* Viewer Main Header Toolbar */}
      <div className="h-12 border-b border-slate-800 bg-slate-900 px-3 flex items-center justify-between gap-2 shrink-0 select-none">
        {/* Left: Sidebar triggers & Title */}
        <div className="flex items-center gap-1.5 min-w-0">
          <button
            onClick={() => setActiveSidebar(activeSidebar === 'thumbnails' ? null : 'thumbnails')}
            className={`p-1.5 rounded-lg transition ${
              activeSidebar === 'thumbnails' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.thumbnails}
          >
            <LayoutList className="w-4 h-4" />
          </button>
          <button
            onClick={() => setActiveSidebar(activeSidebar === 'bookmarks' ? null : 'bookmarks')}
            className={`p-1.5 rounded-lg transition ${
              activeSidebar === 'bookmarks' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.bookmarks}
          >
            <Bookmark className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          <button
            onClick={() => setIsPageManagerOpen(true)}
            className="flex items-center gap-1 px-2 py-1 text-xs text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title={t.pageManager}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            {!isCompact && <span>{t.pageManager}</span>}
          </button>
        </div>

        {/* Center: Page Counter & Zoom */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-xs text-slate-300 bg-slate-950/60 px-2 py-1 rounded-lg border border-slate-800">
            <span>{t.page}</span>
            <input
              type="number"
              min={1}
              max={doc.pages.length}
              value={activePage + 1}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                if (!isNaN(val) && val >= 1 && val <= doc.pages.length) {
                  scrollToPage(val - 1);
                }
              }}
              className="w-8 text-center bg-transparent border-b border-rose-500 font-semibold text-rose-400 outline-none"
            />
            <span className="text-slate-500">{t.of} {doc.pages.length}</span>
          </div>

          <div className="flex items-center gap-1 bg-slate-950/60 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setZoom((prev) => Math.max(50, prev - 15))}
              className="p-1 text-slate-400 hover:text-white rounded"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono text-slate-300 w-9 text-center">{zoom}%</span>
            <button
              onClick={() => setZoom((prev) => Math.min(250, prev + 15))}
              className="p-1 text-slate-400 hover:text-white rounded"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Reading Mode Switcher */}
          <div className="flex items-center bg-slate-950/60 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setReadingMode('light')}
              className={`p-1 rounded transition ${readingMode === 'light' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title={t.lightMode}
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setReadingMode('sepia')}
              className={`p-1 rounded transition ${readingMode === 'sepia' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title={t.sepiaMode}
            >
              <Coffee className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setReadingMode('night')}
              className={`p-1 rounded transition ${readingMode === 'night' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
              title={t.nightMode}
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right: Search, Bookmark, Save */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={toggleBookmark}
            className={`p-1.5 rounded-lg transition ${
              isPageBookmarked ? 'text-amber-400 bg-amber-500/10' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={isPageBookmarked ? t.removeBookmark : t.addBookmark}
          >
            {isPageBookmarked ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={`p-1.5 rounded-lg transition ${
              isSearchOpen ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.searchPlaceholder}
          >
            <Search className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Save & Export */}
          <button
            onClick={() => onSaveDoc(doc)}
            className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-lg transition ${
              doc.isModified
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-950'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
            title={t.save}
          >
            <Save className="w-3.5 h-3.5" />
            {!isCompact && <span>{t.save}</span>}
          </button>

          <button
            onClick={() => exportDocumentToPdf(doc, '_Copy')}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title={t.saveAsCopy}
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Floating / Secondary Annotation Toolbar */}
      <div className="h-11 border-b border-slate-800/80 bg-slate-900/90 backdrop-blur px-3 flex items-center justify-between gap-1 overflow-x-auto shrink-0 select-none">
        {/* Annotation Tools */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTool('select')}
            className={`px-2.5 py-1 text-xs rounded-lg flex items-center gap-1.5 transition ${
              activeTool === 'select' ? 'bg-rose-600 text-white font-medium' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span>{t.selectTool}</span>
          </button>

          <button
            onClick={() => setActiveTool('pen')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'pen' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.penTool}
          >
            <PenTool className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('highlight')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'highlight' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.highlightTool}
          >
            <Highlighter className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('rect')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'rect' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.rectTool}
          >
            <Square className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('ellipse')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'ellipse' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.ellipseTool}
          >
            <Circle className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('arrow')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'arrow' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.arrowTool}
          >
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => setActiveTool('note')}
            className={`p-1.5 rounded-lg transition ${
              activeTool === 'note' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={t.noteTool}
          >
            <MessageSquare className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsSignatureModalOpen(true)}
            className="flex items-center gap-1 px-2 py-1 text-xs text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 rounded-lg border border-rose-800/50 transition"
            title={t.signatureTool}
          >
            <FileSignature className="w-3.5 h-3.5 text-rose-400" />
            {!isCompact && <span>{t.signatureTool}</span>}
          </button>
        </div>

        {/* Color Palette & Stroke Width */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-950/60 px-2 py-1 rounded-lg border border-slate-800">
            {['#e11d48', '#2563eb', '#16a34a', '#ca8a04', '#7c3aed', '#0f172a'].map((color) => (
              <button
                key={color}
                onClick={() => setActiveColor(color)}
                className={`w-4 h-4 rounded-full transition ${
                  activeColor === color ? 'ring-2 ring-white scale-125' : 'opacity-70 hover:opacity-100'
                }`}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>

          {/* Undo / Redo */}
          <div className="flex items-center gap-0.5">
            <button
              onClick={handleUndo}
              disabled={undoStack.length === 0}
              className="p-1.5 text-slate-400 hover:text-white disabled:opacity-30 rounded-lg hover:bg-slate-800 transition"
              title={t.undo}
            >
              <Undo className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              className="p-1.5 text-slate-400 hover:text-white disabled:opacity-30 rounded-lg hover:bg-slate-800 transition"
              title={t.redo}
            >
              <Redo className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Search Header Overlay */}
      {isSearchOpen && (
        <div className="h-10 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between text-xs animate-in slide-in-from-top duration-150">
          <div className="flex items-center gap-2 flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentMatchIndex(0);
              }}
              placeholder={t.searchPlaceholder}
              autoFocus
              className="w-full bg-slate-950 text-slate-100 px-2.5 py-1 rounded-md border border-slate-700 outline-none focus:border-rose-500"
            />
          </div>

          <div className="flex items-center gap-2 text-slate-400">
            {searchQuery ? (
              <span>
                {searchMatches.length > 0 ? (
                  <>
                    <span className="text-rose-400 font-semibold">{currentMatchIndex + 1}</span> of{' '}
                    <span>{searchMatches.length}</span> matches
                  </>
                ) : (
                  <span>{t.noResults}</span>
                )}
              </span>
            ) : null}

            <button
              onClick={handlePrevMatch}
              disabled={searchMatches.length === 0}
              className="p-1 hover:bg-slate-800 rounded disabled:opacity-30"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextMatch}
              disabled={searchMatches.length === 0}
              className="p-1 hover:bg-slate-800 rounded disabled:opacity-30"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsSearchOpen(false)}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Document Workspace Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar (Thumbnails or Bookmarks) */}
        {activeSidebar && (
          <div className="w-64 border-r border-slate-800 bg-slate-900/90 backdrop-blur flex flex-col shrink-0 overflow-y-auto animate-in slide-in-from-left duration-200">
            <div className="p-3 border-b border-slate-800 flex items-center justify-between text-xs font-semibold text-slate-300">
              <span>{activeSidebar === 'thumbnails' ? t.thumbnails : t.bookmarks}</span>
              <button onClick={() => setActiveSidebar(null)} className="p-1 text-slate-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {activeSidebar === 'thumbnails' && (
              <div className="p-3 space-y-3">
                {doc.pages.map((p, idx) => (
                  <div
                    key={idx}
                    onClick={() => scrollToPage(idx)}
                    className={`cursor-pointer rounded-xl p-2 border transition ${
                      activePage === idx ? 'bg-rose-950/40 border-rose-500' : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div 
                      className="aspect-[3/4] bg-white rounded p-2 text-[8px] text-slate-800 overflow-hidden shadow"
                      style={{ transform: `rotate(${p.rotation}deg)` }}
                    >
                      <div className="font-bold text-slate-900 truncate mb-1">{p.title}</div>
                      <div className="text-slate-400 line-clamp-4">{p.content[0]}</div>
                    </div>
                    <div className="flex items-center justify-between mt-1 text-[11px] text-slate-400">
                      <span>{t.page} {idx + 1}</span>
                      {p.annotations.length > 0 && (
                        <span className="text-[10px] text-rose-400 font-semibold">{p.annotations.length} edits</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeSidebar === 'bookmarks' && (
              <div className="p-3 space-y-2">
                {doc.bookmarks.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No bookmarks yet. Click the bookmark icon in the top toolbar to pin pages.
                  </div>
                ) : (
                  doc.bookmarks.map((bm) => (
                    <div
                      key={bm.id}
                      onClick={() => scrollToPage(bm.pageIndex)}
                      className="p-2.5 bg-slate-950/50 border border-slate-800 hover:border-slate-700 rounded-xl cursor-pointer flex items-center justify-between group transition"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <Bookmark className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span className="text-xs text-slate-200 truncate">{bm.title}</span>
                      </div>
                      <span className="text-[10px] text-slate-500">P.{bm.pageIndex + 1}</span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        )}

        {/* Continuous Page Scroll Stream */}
        <div 
          ref={containerRef}
          className={`flex-1 overflow-y-auto p-8 flex flex-col items-center gap-8 ${themeClasses.bg}`}
        >
          {doc.pages.map((page, pIdx) => {
            const isMatchOnPage = searchMatches.some((m) => m.pageIndex === pIdx);

            return (
              <div
                key={`${page.index}-${pIdx}`}
                ref={(el) => {
                  pageRefs.current[pIdx] = el;
                }}
                onMouseDown={(e) => handlePageMouseDown(pIdx, e)}
                onMouseMove={handlePageMouseMove}
                onMouseUp={() => handlePageMouseUp(pIdx)}
                className={`relative rounded-xl transition-transform origin-top select-none ${themeClasses.page} ${
                  isMatchOnPage ? 'ring-2 ring-rose-500/50' : ''
                }`}
                style={{
                  width: `${600 * (zoom / 100)}px`,
                  minHeight: `${850 * (zoom / 100)}px`,
                  transform: `rotate(${page.rotation}deg)`,
                  cursor: activeTool === 'select' ? 'default' : 'crosshair',
                }}
              >
                {/* Visual Page Sheet Content */}
                <div 
                  className="p-10 space-y-5"
                  style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
                >
                  {/* Header info */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200/40 text-[11px] text-slate-400">
                    <span className="font-semibold uppercase tracking-wider">{doc.name}</span>
                    <span>{t.page} {pIdx + 1} / {doc.pages.length}</span>
                  </div>

                  {/* Title */}
                  <h2 className="text-xl font-bold tracking-tight pb-2">{page.title}</h2>

                  {/* Paragraphs with search term highlighting */}
                  <div className="space-y-4 text-xs leading-relaxed">
                    {page.content.map((p, lineIdx) => {
                      const isHeader = p.startsWith('# ');
                      const text = isHeader ? p.replace('# ', '') : p;

                      // Highlight search keywords
                      if (searchQuery.trim() && text.toLowerCase().includes(searchQuery.toLowerCase())) {
                        const parts = text.split(new RegExp(`(${searchQuery})`, 'gi'));
                        return (
                          <p key={lineIdx} className={isHeader ? 'text-sm font-bold text-rose-600 mt-2' : ''}>
                            {parts.map((part, i) =>
                              part.toLowerCase() === searchQuery.toLowerCase() ? (
                                <mark key={i} className="bg-amber-300 text-slate-900 px-0.5 rounded font-semibold">
                                  {part}
                                </mark>
                              ) : (
                                part
                              )
                            )}
                          </p>
                        );
                      }

                      return (
                        <p key={lineIdx} className={isHeader ? 'text-sm font-bold text-rose-600 mt-2' : ''}>
                          {text}
                        </p>
                      );
                    })}
                  </div>
                </div>

                {/* SVG Vector Annotations Layer */}
                <svg
                  className="absolute inset-0 w-full h-full pointer-events-none"
                  viewBox={`0 0 ${600} ${850}`}
                  preserveAspectRatio="none"
                >
                  {page.annotations.map((ann) => {
                    if (ann.type === 'pen' || ann.type === 'highlight') {
                      if (ann.points.length < 2) return null;
                      const pathData = ann.points.reduce(
                        (acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`,
                        ''
                      );
                      return (
                        <path
                          key={ann.id}
                          d={pathData}
                          stroke={ann.color}
                          strokeWidth={ann.strokeWidth}
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeOpacity={ann.opacity || 1}
                          fill="none"
                        />
                      );
                    } else if (ann.type === 'rect') {
                      const x = Math.min(ann.start.x, ann.end.x);
                      const y = Math.min(ann.start.y, ann.end.y);
                      const width = Math.abs(ann.end.x - ann.start.x);
                      const height = Math.abs(ann.end.y - ann.start.y);
                      return (
                        <rect
                          key={ann.id}
                          x={x}
                          y={y}
                          width={width}
                          height={height}
                          stroke={ann.color}
                          strokeWidth={ann.strokeWidth}
                          fill="none"
                        />
                      );
                    } else if (ann.type === 'ellipse') {
                      const cx = (ann.start.x + ann.end.x) / 2;
                      const cy = (ann.start.y + ann.end.y) / 2;
                      const rx = Math.abs(ann.end.x - ann.start.x) / 2;
                      const ry = Math.abs(ann.end.y - ann.start.y) / 2;
                      return (
                        <ellipse
                          key={ann.id}
                          cx={cx}
                          cy={cy}
                          rx={rx}
                          ry={ry}
                          stroke={ann.color}
                          strokeWidth={ann.strokeWidth}
                          fill="none"
                        />
                      );
                    } else if (ann.type === 'arrow') {
                      return (
                        <line
                          key={ann.id}
                          x1={ann.start.x}
                          y1={ann.start.y}
                          x2={ann.end.x}
                          y2={ann.end.y}
                          stroke={ann.color}
                          strokeWidth={ann.strokeWidth}
                          strokeLinecap="round"
                        />
                      );
                    }
                    return null;
                  })}

                  {/* Active drawing stroke preview */}
                  {isInteracting && currentStroke.length > 1 && (
                    <path
                      d={currentStroke.reduce(
                        (acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`,
                        ''
                      )}
                      stroke={activeColor}
                      strokeWidth={activeTool === 'highlight' ? 14 : activeStrokeWidth}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeOpacity={activeTool === 'highlight' ? 0.4 : 1}
                      fill="none"
                    />
                  )}

                  {/* Active shape preview */}
                  {isInteracting && shapeStart && shapeEnd && (
                    <rect
                      x={Math.min(shapeStart.x, shapeEnd.x)}
                      y={Math.min(shapeStart.y, shapeEnd.y)}
                      width={Math.abs(shapeEnd.x - shapeStart.x)}
                      height={Math.abs(shapeEnd.y - shapeStart.y)}
                      stroke={activeColor}
                      strokeWidth={activeStrokeWidth}
                      fill="none"
                    />
                  )}
                </svg>

                {/* HTML Interactive Annotations: Sticky Notes & Digital Signatures */}
                {page.annotations.map((ann) => {
                  if (ann.type === 'note') {
                    return (
                      <div
                        key={ann.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveNoteEditing({ pageIndex: pIdx, annId: ann.id });
                          setNoteInputText(ann.text);
                        }}
                        style={{
                          left: `${ann.position.x * (zoom / 100)}px`,
                          top: `${ann.position.y * (zoom / 100)}px`,
                        }}
                        className="absolute p-2 bg-amber-100 border border-amber-300 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition max-w-[180px] text-[11px] text-slate-800"
                      >
                        <div className="flex items-center gap-1 font-semibold text-[10px] text-amber-800 mb-0.5">
                          <MessageSquare className="w-3 h-3" />
                          <span>{ann.author}</span>
                        </div>
                        <p className="line-clamp-3">{ann.text}</p>
                      </div>
                    );
                  } else if (ann.type === 'signature') {
                    return (
                      <div
                        key={ann.id}
                        style={{
                          left: `${ann.position.x * (zoom / 100)}px`,
                          top: `${ann.position.y * (zoom / 100)}px`,
                          width: `${ann.width * (zoom / 100)}px`,
                          height: `${ann.height * (zoom / 100)}px`,
                        }}
                        className="absolute border border-dashed border-rose-400/50 rounded-lg p-1 bg-white/70 backdrop-blur-xs shadow-sm flex items-center justify-center cursor-move"
                      >
                        <img src={ann.dataUrl} alt="Signature" className="max-w-full max-h-full object-contain" />
                      </div>
                    );
                  }
                  return null;
                })}
              </div>
            );
          })}
        </div>
      </div>

      {/* Note Edit Modal */}
      {activeNoteEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-sm w-full space-y-3">
            <h4 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-400" />
              {t.noteTool}
            </h4>
            <textarea
              value={noteInputText}
              onChange={(e) => setNoteInputText(e.target.value)}
              rows={4}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-100 focus:border-amber-400 outline-none"
            />
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                onClick={() => setActiveNoteEditing(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  recordHistory();
                  const updatedPages = [...doc.pages];
                  const page = updatedPages[activeNoteEditing.pageIndex];
                  const note = page.annotations.find((a) => a.id === activeNoteEditing.annId) as NoteAnnotation;
                  if (note) {
                    note.text = noteInputText;
                  }
                  onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
                  setActiveNoteEditing(null);
                }}
                className="px-4 py-1.5 text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-900 rounded-lg"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Signature Capture Modal */}
      <SignatureModal
        isOpen={isSignatureModalOpen}
        onClose={() => setIsSignatureModalOpen(false)}
        onSave={insertSignatureOnPage}
        lang={lang}
      />

      {/* Page Manager Modal */}
      <PageManagerModal
        isOpen={isPageManagerOpen}
        doc={doc}
        onClose={() => setIsPageManagerOpen(false)}
        lang={lang}
        onRotatePage={(pIdx, deg) => {
          recordHistory();
          const updatedPages = [...doc.pages];
          updatedPages[pIdx].rotation = (updatedPages[pIdx].rotation + deg + 360) % 360;
          onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
        }}
        onDeletePage={(pIdx) => {
          if (doc.pages.length <= 1) return;
          recordHistory();
          const updatedPages = doc.pages.filter((_, i) => i !== pIdx);
          onUpdateDoc({
            ...doc,
            pages: updatedPages,
            totalPages: updatedPages.length,
            isModified: true,
          });
        }}
        onDuplicatePage={(pIdx) => {
          recordHistory();
          const original = doc.pages[pIdx];
          const duplicate: PdfPage = {
            ...JSON.parse(JSON.stringify(original)),
            title: `${original.title} (Copy)`,
            index: doc.pages.length,
          };
          const updatedPages = [...doc.pages];
          updatedPages.splice(pIdx + 1, 0, duplicate);
          onUpdateDoc({
            ...doc,
            pages: updatedPages,
            totalPages: updatedPages.length,
            isModified: true,
          });
        }}
        onMovePage={(from, to) => {
          if (to < 0 || to >= doc.pages.length) return;
          recordHistory();
          const updatedPages = [...doc.pages];
          const [moved] = updatedPages.splice(from, 1);
          updatedPages.splice(to, 0, moved);
          onUpdateDoc({ ...doc, pages: updatedPages, isModified: true });
        }}
      />
    </div>
  );
};
