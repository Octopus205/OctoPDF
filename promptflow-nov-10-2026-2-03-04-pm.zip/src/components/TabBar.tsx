import React from 'react';
import { Plus, X, FileText, Star, AlertCircle } from 'lucide-react';
import { PdfDocument, AppLanguage } from '../types/pdf';
import { TRANSLATIONS } from '../data/translations';

interface TabBarProps {
  documents: PdfDocument[];
  activeDocId: string;
  onSelectDoc: (id: string) => void;
  onRequestCloseDoc: (doc: PdfDocument) => void;
  onNewDoc: () => void;
  lang: AppLanguage;
}

export const TabBar: React.FC<TabBarProps> = ({
  documents,
  activeDocId,
  onSelectDoc,
  onRequestCloseDoc,
  onNewDoc,
  lang,
}) => {
  const t = TRANSLATIONS[lang];

  return (
    <div className="h-11 border-b border-slate-800 bg-slate-950 px-2 flex items-center gap-1.5 overflow-x-auto select-none shrink-0">
      {documents.map((doc) => {
        const isActive = doc.id === activeDocId;

        return (
          <div
            key={doc.id}
            onClick={() => onSelectDoc(doc.id)}
            className={`group relative flex items-center gap-2 px-3 py-1.5 text-xs rounded-xl cursor-pointer transition border ${
              isActive
                ? 'bg-slate-900 border-slate-700 text-slate-100 shadow-sm'
                : 'bg-slate-950 border-transparent text-slate-400 hover:bg-slate-900/60 hover:text-slate-300'
            }`}
          >
            {/* Modified Dot indicator */}
            {doc.isModified ? (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse shrink-0" title="Unsaved changes" />
            ) : (
              <FileText className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-rose-400' : 'text-slate-500'}`} />
            )}

            <span className="truncate max-w-[140px] font-medium">{doc.name}</span>

            {doc.isFavorite && (
              <Star className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />
            )}

            {/* Close tab */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRequestCloseDoc(doc);
              }}
              className="p-1 rounded-md text-slate-500 hover:text-slate-200 hover:bg-slate-800 transition"
              title={t.close}
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        );
      })}

      {/* Add new tab / Open Document */}
      <button
        onClick={onNewDoc}
        className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-900 rounded-lg transition shrink-0 ml-1"
        title={t.openFile}
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
};
