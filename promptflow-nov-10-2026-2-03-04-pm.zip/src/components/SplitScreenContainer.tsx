import React, { useState } from 'react';
import { ArrowLeftRight, Columns2, X, ChevronDown } from 'lucide-react';
import { PdfDocument, AppLanguage } from '../types/pdf';
import { PdfViewerPane } from './PdfViewerPane';
import { TRANSLATIONS } from '../data/translations';

interface SplitScreenContainerProps {
  documents: PdfDocument[];
  leftDocId: string;
  rightDocId: string;
  onSelectLeftDoc: (id: string) => void;
  onSelectRightDoc: (id: string) => void;
  onUpdateDoc: (updated: PdfDocument) => void;
  onSaveDoc: (doc: PdfDocument) => void;
  onExitSplit: () => void;
  lang: AppLanguage;
}

export const SplitScreenContainer: React.FC<SplitScreenContainerProps> = ({
  documents,
  leftDocId,
  rightDocId,
  onSelectLeftDoc,
  onSelectRightDoc,
  onUpdateDoc,
  onSaveDoc,
  onExitSplit,
  lang,
}) => {
  const t = TRANSLATIONS[lang];
  const [splitRatio, setSplitRatio] = useState<number>(50); // 50% default

  const leftDoc = documents.find((d) => d.id === leftDocId) || documents[0];
  const rightDoc = documents.find((d) => d.id === rightDocId) || (documents[1] || documents[0]);

  const handleSwapPanes = () => {
    const temp = leftDocId;
    onSelectLeftDoc(rightDocId);
    onSelectRightDoc(temp);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 overflow-hidden">
      {/* Split Control Header */}
      <div className="h-10 border-b border-slate-800 bg-slate-900/90 px-4 flex items-center justify-between text-xs shrink-0 select-none">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-rose-400 font-semibold">
            <Columns2 className="w-4 h-4" />
            <span>{t.dualView}</span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Left doc selector */}
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-[11px] text-slate-500">{t.splitLeft}:</span>
            <select
              value={leftDoc.id}
              onChange={(e) => onSelectLeftDoc(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-xs text-slate-200 px-2 py-0.5 rounded-lg outline-none"
            >
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* Swap Button */}
          <button
            onClick={handleSwapPanes}
            className="flex items-center gap-1 px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition"
            title={t.swapPanes}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span className="text-[11px]">{t.swapPanes}</span>
          </button>

          {/* Right doc selector */}
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-[11px] text-slate-500">{t.splitRight}:</span>
            <select
              value={rightDoc.id}
              onChange={(e) => onSelectRightDoc(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-xs text-slate-200 px-2 py-0.5 rounded-lg outline-none"
            >
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Ratio options & Exit */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-950/60 p-0.5 rounded-lg border border-slate-800 text-[10px]">
            <button
              onClick={() => setSplitRatio(35)}
              className={`px-2 py-0.5 rounded ${splitRatio === 35 ? 'bg-rose-600 text-white' : 'text-slate-400'}`}
            >
              35/65
            </button>
            <button
              onClick={() => setSplitRatio(50)}
              className={`px-2 py-0.5 rounded ${splitRatio === 50 ? 'bg-rose-600 text-white' : 'text-slate-400'}`}
            >
              50/50
            </button>
            <button
              onClick={() => setSplitRatio(65)}
              className={`px-2 py-0.5 rounded ${splitRatio === 65 ? 'bg-rose-600 text-white' : 'text-slate-400'}`}
            >
              65/35
            </button>
          </div>

          <button
            onClick={onExitSplit}
            className="flex items-center gap-1 px-2.5 py-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title={t.singleView}
          >
            <X className="w-3.5 h-3.5" />
            <span>{t.singleView}</span>
          </button>
        </div>
      </div>

      {/* Side-by-side Dual Panes */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Pane */}
        <div
          className="h-full flex flex-col border-r border-slate-800 overflow-hidden"
          style={{ width: `${splitRatio}%` }}
        >
          <PdfViewerPane
            doc={leftDoc}
            onUpdateDoc={onUpdateDoc}
            onSaveDoc={onSaveDoc}
            lang={lang}
            isCompact={true}
          />
        </div>

        {/* Right Pane */}
        <div
          className="h-full flex flex-col overflow-hidden"
          style={{ width: `${100 - splitRatio}%` }}
        >
          <PdfViewerPane
            doc={rightDoc}
            onUpdateDoc={onUpdateDoc}
            onSaveDoc={onSaveDoc}
            lang={lang}
            isCompact={true}
          />
        </div>
      </div>
    </div>
  );
};
