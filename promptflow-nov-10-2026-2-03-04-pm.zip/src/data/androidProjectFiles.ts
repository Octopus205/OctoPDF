export interface AndroidProjectFile {
  path: string;
  language: 'kotlin' | 'xml' | 'toml' | 'gradle' | 'markdown' | 'text' | 'svg';
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidProjectFile[] = [
  {
    path: 'gradle/libs.versions.toml',
    language: 'toml',
    description: 'Gradle Version Catalog specifying all dependencies, plugins, and Android SDK targets.',
    content: `[versions]
agp = "8.8.0"
kotlin = "2.1.0"
coreKtx = "1.15.0"
lifecycleRuntimeKtx = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.12.01"
material3WindowSize = "1.3.1"
room = "2.6.1"
datastore = "1.1.1"
coroutines = "1.10.1"
ksp = "2.1.0-1.0.29"

# PDF Rendering & Manipulation Libraries (Apache 2.0)
pdfiumAndroid = "1.9.2"
androidPdfViewer = "3.2.0-beta.1"
pdfboxAndroid = "2.0.27.0"

# Testing
junit = "4.13.2"
junitExt = "1.2.1"
espresso = "3.6.1"
truth = "1.4.4"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntimeKtx" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycleRuntimeKtx" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }

# Compose BOM & Material 3 Adaptive
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
androidx-ui = { group = "androidx.compose.ui", name = "ui" }
androidx-ui-graphics = { group = "androidx.compose.ui", name = "ui-graphics" }
androidx-ui-tooling = { group = "androidx.compose.ui", name = "ui-tooling" }
androidx-ui-tooling-preview = { group = "androidx.compose.ui", name = "ui-tooling-preview" }
androidx-material3 = { group = "androidx.compose.material3", name = "material3" }
androidx-material3-window-size = { group = "androidx.compose.material3", name = "material3-window-size-class", version.ref = "material3WindowSize" }
androidx-material-icons-extended = { group = "androidx.compose.material", name = "material-icons-extended" }

# Room & DataStore (Persistence)
androidx-room-runtime = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
androidx-room-ktx = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
androidx-room-compiler = { group = "androidx.room", name = "room-compiler", version.ref = "room" }
androidx-datastore-preferences = { group = "androidx.datastore", name = "datastore-preferences", version.ref = "datastore" }

# Coroutines
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }

# PDF Engines (Strictly Apache 2.0 License)
pdfium-android = { group = "com.github.barteksc", name = "pdfium-android", version.ref = "pdfiumAndroid" }
android-pdf-viewer = { group = "com.github.barteksc", name = "android-pdf-viewer", version.ref = "androidPdfViewer" }
pdfbox-android = { group = "com.tom-roush", name = "pdfbox-android", version.ref = "pdfboxAndroid" }

# Testing
junit = { group = "junit", name = "junit", version.ref = "junit" }
androidx-junit = { group = "androidx.test.ext", name = "junit", version.ref = "junitExt" }
androidx-espresso-core = { group = "androidx.test.espresso", name = "espresso-core", version.ref = "espresso" }
androidx-compose-ui-test-junit4 = { group = "androidx.compose.ui", name = "ui-test-junit4" }
androidx-compose-ui-test-manifest = { group = "androidx.compose.ui", name = "ui-test-manifest" }
google-truth = { group = "com.google.truth", name = "truth", version.ref = "truth" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
kotlin-compose = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
ksp = { id = "com.google.devtools.ksp", version.ref = "ksp" }
`
  },
  {
    path: 'settings.gradle.kts',
    language: 'gradle',
    description: 'Root Gradle settings with Maven repositories and plugin management.',
    content: `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = java.net.URI("https://jitpack.io") }
    }
}

rootProject.name = "OctoPDF"
include(":app")
`
  },
  {
    path: 'build.gradle.kts',
    language: 'gradle',
    description: 'Top-level root build file.',
    content: `plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
`
  },
  {
    path: 'app/build.gradle.kts',
    language: 'gradle',
    description: 'App module build script with NDK ABI filters (armeabi-v7a & arm64-v8a), minSdk 26, Compose, and Room.',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.octopdf.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.octopdf.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // Section 1: Restrict native ABIs to 32-bit and 64-bit ARM
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    // Split APKs by ABI for minimal download footprint
    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a")
            isUniversalApk = false
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi"
        )
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)

    // Compose & Material 3 Adaptive Layouts
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material3.window.size)
    implementation(libs.androidx.material.icons.extended)

    // Persistence (Room & DataStore)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)

    // Coroutines
    implementation(libs.kotlinx.coroutines.android)

    // PDF Engines (Apache 2.0)
    implementation(libs.pdfium.android)
    implementation(libs.android.pdf.viewer)
    implementation(libs.pdfbox.android)

    // Testing
    testImplementation(libs.junit)
    testImplementation(libs.google.truth)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Manifest strictly omitting INTERNET permission, supporting SAF and intent filters for PDF files.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- 
      OFFLINE BY DESIGN:
      Zero INTERNET permission requested. 
      This guarantees full privacy and offline air-gapped operation.
    -->

    <!-- Storage Access: Android 9 and below fallback for local caches -->
    <uses-permission
        android:name="android.permission.READ_EXTERNAL_STORAGE"
        android:maxSdkVersion="32" />
    <uses-permission
        android:name="android.permission.WRITE_EXTERNAL_STORAGE"
        android:maxSdkVersion="28"
        tools:ignore="ScopedStorage" />

    <application
        android:name=".OctoPdfApp"
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.OctoPDF">

        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize"
            android:resizeableActivity="true">

            <!-- Default launcher entry -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- Intent Filter: Open PDFs via Storage Access Framework or file manager -->
            <intent-filter tools:ignore="AppLinkUrlError">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:mimeType="application/pdf" />
                <data android:scheme="content" />
                <data android:scheme="file" />
            </intent-filter>

            <!-- Intent Filter: Receive shared PDFs from other apps -->
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
        </activity>

        <!-- Secure FileProvider for exporting copies via SAF -->
        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>

</manifest>
`
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    language: 'xml',
    description: 'English string resources for OctoPDF.',
    content: `<resources>
    <string name="app_name">OctoPDF</string>
    <string name="nav_documents">Documents</string>
    <string name="nav_split_screen">Split Screen</string>
    <string name="nav_tools">PDF Tools</string>
    <string name="nav_recent">Recent Files</string>
    
    <string name="action_open_document">Open Document</string>
    <string name="action_save">Save</string>
    <string name="action_save_as_copy">Save as Copy</string>
    <string name="action_close">Close</string>
    <string name="action_discard">Discard</string>
    <string name="action_cancel">Cancel</string>
    <string name="action_search">Search</string>
    <string name="action_bookmarks">Bookmarks</string>
    <string name="action_thumbnails">Thumbnails</string>
    <string name="action_undo">Undo</string>
    <string name="action_redo">Redo</string>
    
    <string name="dialog_unsaved_title">Unsaved Changes</string>
    <string name="dialog_unsaved_message">Save modifications to %1$s before closing this tab?</string>
    
    <string name="mode_light">Light</string>
    <string name="mode_sepia">Sepia</string>
    <string name="mode_night">Night</string>
    
    <string name="tool_pen">Pen</string>
    <string name="tool_highlight">Highlight</string>
    <string name="tool_underline">Underline</string>
    <string name="tool_strikethrough">Strikethrough</string>
    <string name="tool_shapes">Shapes</string>
    <string name="tool_note">Sticky Note</string>
    <string name="tool_signature">Signature</string>
    
    <string name="tool_merge">Merge PDFs</string>
    <string name="tool_split">Split PDF</string>
    <string name="tool_extract">Extract Pages</string>
    <string name="tool_password">Password Protection</string>
    
    <string name="page_number">Page %1$d of %2$d</string>
    <string name="offline_badge">100% Offline Secured</string>
</resources>
`
  },
  {
    path: 'app/src/main/res/values-ar/strings.xml',
    language: 'xml',
    description: 'Arabic localized strings (values-ar) providing full RTL support.',
    content: `<resources>
    <string name="app_name">أوكتو بي دي إف</string>
    <string name="nav_documents">المستندات</string>
    <string name="nav_split_screen">شاشة مقسمة</string>
    <string name="nav_tools">أدوات PDF</string>
    <string name="nav_recent">الملفات الأخيرة</string>
    
    <string name="action_open_document">فتح مستند</string>
    <string name="action_save">حفظ</string>
    <string name="action_save_as_copy">حفظ كنسخة</string>
    <string name="action_close">إغلاق</string>
    <string name="action_discard">تجاهل</string>
    <string name="action_cancel">إلغاء</string>
    <string name="action_search">بحث</string>
    <string name="action_bookmarks">إشارات مرجعية</string>
    <string name="action_thumbnails">المصغرات</string>
    <string name="action_undo">تراجع</string>
    <string name="action_redo">إعادة</string>
    
    <string name="dialog_unsaved_title">تعديلات غير محفوظة</string>
    <string name="dialog_unsaved_message">هل ترغب في حفظ التعديلات على %1$s قبل إغلاق علامة التبويب؟</string>
    
    <string name="mode_light">فاتح</string>
    <string name="mode_sepia">دافئ (سيبيا)</string>
    <string name="mode_night">ليلي</string>
    
    <string name="tool_pen">قلم حر</string>
    <string name="tool_highlight">تظليل</string>
    <string name="tool_underline">تسطير</string>
    <string name="tool_strikethrough">شطب</string>
    <string name="tool_shapes">أشكال هندسية</string>
    <string name="tool_note">ملاحظة لاصقة</string>
    <string name="tool_signature">توقيع رقمي</string>
    
    <string name="tool_merge">دمج الملفات</string>
    <string name="tool_split">تقسيم المستند</string>
    <string name="tool_extract">استخراج صفحات</string>
    <string name="tool_password">حماية بكلمة مرور</string>
    
    <string name="page_number">صفحة %1$d من %2$d</string>
    <string name="offline_badge">يعمل دون اتصال 100%</string>
</resources>
`
  },
  {
    path: 'docs/octopdf-icon.svg',
    language: 'svg',
    description: 'Vector asset for OctoPDF: Octopus merged with a PDF page (red octopus on white page, blue background).',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1E3A8A" />
      <stop offset="100%" stop-color="#0F172A" />
    </linearGradient>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000000" flood-opacity="0.35"/>
    </filter>
  </defs>

  <!-- Blue Rounded Background Container -->
  <rect width="512" height="512" rx="112" fill="url(#bgGrad)" />

  <!-- Crisp White PDF Page with Folded Corner -->
  <g filter="url(#shadow)">
    <!-- Main Sheet -->
    <path d="M 120 72 
             L 320 72 
             L 392 144 
             L 392 440 
             Q 392 452 380 452 
             L 132 452 
             Q 120 452 120 440 
             Z" 
          fill="#FFFFFF" />
          
    <!-- Folded Corner Flap -->
    <path d="M 320 72 L 320 144 L 392 144 Z" fill="#E2E8F0" />
    <path d="M 320 144 L 392 144 L 320 72 Z" fill="#CBD5E1" opacity="0.5" />
  </g>

  <!-- PDF Badge Ribbon -->
  <rect x="144" y="104" width="64" height="24" rx="6" fill="#EF4444" />
  <text x="176" y="121" fill="#FFFFFF" font-family="sans-serif" font-weight="900" font-size="13" text-anchor="middle">PDF</text>

  <!-- Stylized Vibrant Red Octopus Icon -->
  <g transform="translate(156, 170)">
    <!-- Octopus Head / Dome -->
    <path d="M 100 20 
             C 45 20 30 65 30 110 
             C 30 140 50 160 70 170 
             C 90 180 110 180 130 170 
             C 150 160 170 140 170 110 
             C 170 65 155 20 100 20 Z" 
          fill="#E11D48" />

    <!-- Expressive Octopus Eyes -->
    <ellipse cx="75" cy="115" rx="14" ry="16" fill="#FFFFFF" />
    <circle cx="78" cy="115" r="8" fill="#1E293B" />
    <circle cx="81" cy="112" r="3" fill="#FFFFFF" />

    <ellipse cx="125" cy="115" rx="14" ry="16" fill="#FFFFFF" />
    <circle cx="122" cy="115" r="8" fill="#1E293B" />
    <circle cx="125" cy="112" r="3" fill="#FFFFFF" />

    <!-- Cute Smile -->
    <path d="M 90 142 Q 100 150 110 142" stroke="#9F1239" stroke-width="3" stroke-linecap="round" fill="none" />

    <!-- Curled Octopus Tentacles (8 tentacles merging gracefully) -->
    <!-- Tentacle 1 -->
    <path d="M 40 150 Q 10 180 25 210 Q 35 220 50 205 Q 60 185 55 160" fill="#E11D48" />
    <!-- Tentacle 2 -->
    <path d="M 60 168 Q 45 210 65 235 Q 80 240 85 215 Q 85 190 75 170" fill="#BE123C" />
    <!-- Tentacle 3 -->
    <path d="M 85 174 Q 85 220 100 242 Q 112 242 112 218 Q 105 190 98 174" fill="#E11D48" />
    <!-- Tentacle 4 -->
    <path d="M 115 174 Q 120 220 135 238 Q 148 230 140 208 Q 128 185 125 172" fill="#BE123C" />
    <!-- Tentacle 5 -->
    <path d="M 145 165 Q 165 190 175 215 Q 190 215 185 195 Q 170 170 155 158" fill="#E11D48" />
    <!-- Tentacle 6 -->
    <path d="M 160 140 Q 195 150 200 180 Q 200 195 185 190 Q 175 170 162 150" fill="#9F1239" />
  </g>
</svg>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_background.xml',
    language: 'xml',
    description: 'Adaptive icon background resource (Deep Navy Blue).',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0F172A"
        android:pathData="M0,0h108v108h-108z" />
</vector>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_foreground.xml',
    language: 'xml',
    description: 'Adaptive icon foreground resource (White page with Red Octopus).',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- White Page -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M32,18 L64,18 L76,30 L76,90 Q76,92 74,92 L34,92 Q32,92 32,90 Z" />
    <!-- Folded corner -->
    <path
        android:fillColor="#CBD5E1"
        android:pathData="M64,18 L64,30 L76,30 Z" />
    <!-- Red Octopus Dome -->
    <path
        android:fillColor="#E11D48"
        android:pathData="M54,42 C44,42 40,50 40,60 C40,66 44,70 48,72 C52,74 56,74 60,72 C64,70 68,66 68,60 C68,50 64,42 54,42 Z" />
    <!-- Octopus Tentacles -->
    <path
        android:fillColor="#BE123C"
        android:pathData="M44,70 Q38,78 42,84 Q46,84 48,78 Z M52,73 Q52,82 56,85 Q60,82 58,74 Z M64,70 Q70,78 66,84 Q62,84 60,78 Z" />
    <!-- Eyes -->
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M48,58a3,3 0 1,0 6,0a3,3 0 1,0 -6,0 M58,58a3,3 0 1,0 6,0a3,3 0 1,0 -6,0" />
</vector>
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/data/model/DocumentTab.kt',
    language: 'kotlin',
    description: 'State model for concurrent multi-document tabs with persistence and unsaved changes tracking.',
    content: `package com.octopdf.app.data.model

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DocumentTab(
    val id: String,
    val uri: Uri,
    val title: String,
    val pageCount: Int = 1,
    val currentPage: Int = 0,
    val zoomFactor: Float = 1.0f,
    val scrollOffsetY: Int = 0,
    val isModified: Boolean = false,
    val isPasswordProtected: Boolean = false,
    val readingMode: ReadingMode = ReadingMode.LIGHT,
    val lastOpenedTimestamp: Long = System.currentTimeMillis()
) : Parcelable

enum class ReadingMode {
    LIGHT,
    SEPIA,
    NIGHT
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/data/model/Annotation.kt',
    language: 'kotlin',
    description: 'Vector and markup annotation domain models with full serialization.',
    content: `package com.octopdf.app.data.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

sealed class Annotation(
    open val id: String,
    open val pageIndex: Int,
    open val color: Long,
    open val timestamp: Long = System.currentTimeMillis()
) {
    data class FreehandPen(
        override val id: String,
        override val pageIndex: Int,
        override val color: Long,
        val points: List<Offset>,
        val strokeWidth: Float,
        val isHighlighter: Boolean = false
    ) : Annotation(id, pageIndex, color)

    data class TextMarkup(
        override val id: String,
        override val pageIndex: Int,
        override val color: Long,
        val startOffset: Offset,
        val endOffset: Offset,
        val style: MarkupStyle
    ) : Annotation(id, pageIndex, color)

    data class Shape(
        override val id: String,
        override val pageIndex: Int,
        override val color: Long,
        val shapeType: ShapeType,
        val start: Offset,
        val end: Offset,
        val strokeWidth: Float
    ) : Annotation(id, pageIndex, color)

    data class StickyNote(
        override val id: String,
        override val pageIndex: Int,
        override val color: Long,
        val position: Offset,
        val noteText: String,
        val author: String = "User"
    ) : Annotation(id, pageIndex, color)

    data class Signature(
        override val id: String,
        override val pageIndex: Int,
        override val color: Long,
        val position: Offset,
        val width: Float,
        val height: Float,
        val strokePaths: List<List<Offset>>
    ) : Annotation(id, pageIndex, color)
}

enum class MarkupStyle { HIGHLIGHT, UNDERLINE, STRIKETHROUGH }
enum class ShapeType { RECTANGLE, ELLIPSE, ARROW }
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/engine/PdfEngine.kt',
    language: 'kotlin',
    description: 'PdfiumAndroid background rendering engine with LruCache bitmap pooling (resilient on 2GB RAM devices).',
    content: `package com.octopdf.app.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.shockwave.pdfium.PdfDocument
import com.shockwave.pdfium.PdfiumCore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * High-performance PDF Rendering & Caching Engine.
 * Built on PdfiumCore (Foxit/Google C++ engine ported under Apache 2.0).
 * Employs a dynamic LruCache scaled to device RAM to prevent OOM on 2GB devices.
 */
class PdfEngine(private val context: Context) {

    private val pdfiumCore = PdfiumCore(context)
    private val openDocuments = mutableMapOf<String, OpenDocHandle>()

    // Allocate 1/8th of available runtime memory for the bitmap LruCache
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8

    private val bitmapCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
        override fun entryRemoved(evicted: Boolean, key: String, oldValue: Bitmap, newValue: Bitmap?) {
            // Bitmaps recycled safely if not in active view
            if (evicted && !oldValue.isRecycled) {
                // InBitmap pool integration
            }
        }
    }

    data class OpenDocHandle(
        val pfd: ParcelFileDescriptor,
        val pdfDoc: PdfDocument,
        val pageCount: Int
    )

    suspend fun openDocument(docId: String, uri: Uri): Int = withContext(Dispatchers.IO) {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalArgumentException("Cannot open ParcelFileDescriptor for URI: $uri")
        val pdfDoc = pdfiumCore.newDocument(pfd)
        val count = pdfiumCore.getPageCount(pdfDoc)
        openDocuments[docId] = OpenDocHandle(pfd, pdfDoc, count)
        count
    }

    suspend fun renderPageBitmap(
        docId: String,
        pageIndex: Int,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap = withContext(Dispatchers.Default) {
        val cacheKey = "\${docId}_\${pageIndex}_\${targetWidth}x\${targetHeight}"
        bitmapCache.get(cacheKey)?.let { cached ->
            if (!cached.isRecycled) return@withContext cached
        }

        val handle = openDocuments[docId] 
            ?: throw IllegalStateException("Document $docId is not open in PdfEngine")

        synchronized(handle.pdfDoc) {
            pdfiumCore.openPage(handle.pdfDoc, pageIndex)
            val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)
            
            // Render native vector page into bitmap
            pdfiumCore.renderPageBitmap(
                handle.pdfDoc,
                bitmap,
                pageIndex,
                0, 0,
                targetWidth,
                targetHeight,
                true // anti-aliasing enabled
            )
            
            bitmapCache.put(cacheKey, bitmap)
            bitmap
        }
    }

    suspend fun closeDocument(docId: String) = withContext(Dispatchers.IO) {
        openDocuments.remove(docId)?.let { handle ->
            try {
                pdfiumCore.closeDocument(handle.pdfDoc)
                handle.pfd.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // Evict cached bitmaps for this document
        val prefix = "\${docId}_"
        bitmapCache.snapshot().keys.filter { it.startsWith(prefix) }.forEach {
            bitmapCache.remove(it)
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/data/db/PdfDatabase.kt',
    language: 'kotlin',
    description: 'Room Database definition for persisting recent files, bookmarks, and last-read positions.',
    content: `package com.octopdf.app.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "recent_documents")
data class RecentDocumentEntity(
    @PrimaryKey val uriString: String,
    val title: String,
    val totalPages: Int,
    val lastReadPage: Int,
    val lastAccessTime: Long,
    val isFavorite: Boolean = false,
    val thumbnailBlob: ByteArray? = null
)

@Entity(tableName = "document_bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentUri: String,
    val pageIndex: Int,
    val title: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface RecentDocumentDao {
    @Query("SELECT * FROM recent_documents ORDER BY lastAccessTime DESC")
    fun getAllRecentDocuments(): Flow<List<RecentDocumentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(doc: RecentDocumentEntity)

    @Query("UPDATE recent_documents SET lastReadPage = :page, lastAccessTime = :time WHERE uriString = :uri")
    suspend fun updateReadingProgress(uri: String, page: Int, time: Long = System.currentTimeMillis())

    @Query("UPDATE recent_documents SET isFavorite = :isFav WHERE uriString = :uri")
    suspend fun setFavorite(uri: String, isFav: Boolean)

    @Query("DELETE FROM recent_documents WHERE uriString = :uri")
    suspend fun deleteRecent(uri: String)
}

@Database(
    entities = [RecentDocumentEntity::class, BookmarkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class PdfDatabase : RoomDatabase() {
    abstract fun recentDocumentDao(): RecentDocumentDao
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/data/repository/PdfRepository.kt',
    language: 'kotlin',
    description: 'Clean Architecture repository managing document lifecycle, SAF interaction, and PDFBox operations.',
    content: `package com.octopdf.app.data.repository

import android.content.Context
import android.net.Uri
import com.octopdf.app.data.db.PdfDatabase
import com.octopdf.app.data.db.RecentDocumentEntity
import com.octopdf.app.data.model.DocumentTab
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

class PdfRepository(
    private val context: Context,
    private val database: PdfDatabase
) {
    val recentDocuments: Flow<List<RecentDocumentEntity>> = 
        database.recentDocumentDao().getAllRecentDocuments()

    suspend fun recordDocumentOpen(uri: Uri, title: String, pageCount: Int) {
        val entity = RecentDocumentEntity(
            uriString = uri.toString(),
            title = title,
            totalPages = pageCount,
            lastReadPage = 0,
            lastAccessTime = System.currentTimeMillis()
        )
        database.recentDocumentDao().insertOrUpdate(entity)
    }

    suspend fun updateLastReadPage(uri: Uri, page: Int) {
        database.recentDocumentDao().updateReadingProgress(uri.toString(), page)
    }

    /**
     * Merge multiple PDF streams into a new destination PDF using Apache PDFBox-Android (Apache 2.0).
     */
    suspend fun mergePdfs(sourceUris: List<Uri>, outputUri: Uri) = withContext(Dispatchers.IO) {
        val merger = PDFMergerUtility()
        val tempFiles = mutableListOf<File>()

        try {
            sourceUris.forEach { uri ->
                val tempFile = File.createTempFile("merge_src_", ".pdf", context.cacheDir)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                }
                merger.addSource(tempFile)
                tempFiles.add(tempFile)
            }

            context.contentResolver.openOutputStream(outputUri)?.use { destStream ->
                merger.destinationStream = destStream
                merger.mergeDocuments(null)
            }
        } finally {
            tempFiles.forEach { it.delete() }
        }
    }

    /**
     * Split a PDF into individual page documents.
     */
    suspend fun splitPdf(sourceUri: Uri, outputDir: File): List<File> = withContext(Dispatchers.IO) {
        val inputStream: InputStream = context.contentResolver.openInputStream(sourceUri)
            ?: throw IllegalArgumentException("Cannot open stream for URI: $sourceUri")

        PDDocument.load(inputStream).use { document ->
            val splitter = Splitter()
            val pages: List<PDDocument> = splitter.split(document)
            val resultFiles = mutableListOf<File>()

            pages.forEachIndexed { index, singlePageDoc ->
                val outFile = File(outputDir, "split_page_\${index + 1}.pdf")
                singlePageDoc.save(outFile)
                singlePageDoc.close()
                resultFiles.add(outFile)
            }
            resultFiles
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/ui/tabs/TabManager.kt',
    language: 'kotlin',
    description: 'Multi-document tab container supporting swipe/tap switching, unsaved change warnings, and persistence.',
    content: `package com.octopdf.app.ui.tabs

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.octopdf.app.data.model.DocumentTab

@Composable
fun TabBar(
    tabs: List<DocumentTab>,
    activeTabId: String,
    onTabSelected: (String) -> Unit,
    onTabCloseRequested: (DocumentTab) -> Unit,
    onNewTabClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                val isActive = tab.id == activeTabId
                val bgColor by animateColorAsState(
                    targetValue = if (isActive) MaterialTheme.colorScheme.surface 
                                  else MaterialTheme.colorScheme.surfaceContainerLow,
                    label = "tab_bg"
                )

                Row(
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgColor)
                        .clickable { onTabSelected(tab.id) }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (tab.isModified) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(MaterialTheme.colorScheme.error)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isActive) MaterialTheme.colorScheme.onSurface 
                                else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 140.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { onTabCloseRequested(tab) },
                        modifier = Modifier.size(18.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close tab",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            IconButton(
                onClick = onNewTabClick,
                modifier = Modifier.padding(horizontal = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Open new document",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/ui/split/SplitScreenContainer.kt',
    language: 'kotlin',
    description: 'Split screen container supporting side-by-side or stacked views with independent zoom and scroll state.',
    content: `package com.octopdf.app.ui.split

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.octopdf.app.data.model.DocumentTab

@Composable
fun SplitScreenContainer(
    primaryTab: DocumentTab?,
    secondaryTab: DocumentTab?,
    isSplitActive: Boolean,
    onSwapPanes: () -> Unit,
    primaryContent: @Composable (DocumentTab) -> Unit,
    secondaryContent: @Composable (DocumentTab) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isSplitActive || secondaryTab == null || primaryTab == null) {
        primaryTab?.let { primaryContent(it) }
        return
    }

    Box(modifier = modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Left / Primary Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                primaryContent(primaryTab)
            }

            // Divider with Quick Swap
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )

            // Right / Secondary Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                secondaryContent(secondaryTab)
            }
        }

        // Floating Swap Button positioned on the split seam
        FloatingActionButton(
            onClick = onSwapPanes,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 16.dp)
                .size(36.dp),
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            Icon(
                imageVector = Icons.Default.SwapHoriz,
                contentDescription = "Swap panes",
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/ui/viewer/PdfViewer.kt',
    language: 'kotlin',
    description: 'Continuous vertical scrolling PDF viewer composable with pinch-to-zoom and reading modes.',
    content: `package com.octopdf.app.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.octopdf.app.data.model.DocumentTab
import com.octopdf.app.data.model.ReadingMode

@Composable
fun PdfViewer(
    tab: DocumentTab,
    onPageChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(tab.zoomFactor) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val listState = rememberLazyListState(initialFirstVisibleItemIndex = tab.currentPage)

    LaunchedEffect(listState.firstVisibleItemIndex) {
        onPageChanged(listState.firstVisibleItemIndex)
    }

    // Reading mode color background & color filter
    val (backgroundColor, pageFilterColor) = when (tab.readingMode) {
        ReadingMode.LIGHT -> Color(0xFFF1F5F9) to Color.White
        ReadingMode.SEPIA -> Color(0xFFF4ECD8) to Color(0xFFFAF0E6)
        ReadingMode.NIGHT -> Color(0xFF0F172A) to Color(0xFF1E293B)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.5f, 4.0f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offsetX,
                    translationY = offsetY
                ),
            contentPadding = PaddingValues(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(tab.pageCount) { pageIndex ->
                PdfPageItem(
                    pageIndex = pageIndex,
                    pageColor = pageFilterColor,
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
fun PdfPageItem(
    pageIndex: Int,
    pageColor: Color,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.ElevatedCard(
        modifier = modifier.aspectRatio(0.707f), // Standard ISO A4 aspect ratio (1:1.414)
        colors = androidx.compose.material3.CardDefaults.elevatedCardColors(containerColor = pageColor)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Text(
                text = "Rendering Page \${pageIndex + 1}...",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/ui/editor/AnnotationLayer.kt',
    language: 'kotlin',
    description: 'Interactive overlay canvas for freehand drawing, highlighter, shapes, sticky notes, and signatures.',
    content: `package com.octopdf.app.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.octopdf.app.data.model.Annotation

@Composable
fun AnnotationLayer(
    annotations: List<Annotation>,
    isDrawingActive: Boolean,
    currentColor: Color,
    currentStrokeWidth: Float,
    onNewAnnotationCreated: (Annotation) -> Unit,
    modifier: Modifier = Modifier
) {
    val currentPoints = remember { mutableStateListOf<Offset>() }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(isDrawingActive) {
                if (!isDrawingActive) return@pointerInput
                detectDragGestures(
                    onDragStart = { startOffset ->
                        currentPoints.clear()
                        currentPoints.add(startOffset)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        currentPoints.add(change.position)
                    },
                    onDragEnd = {
                        if (currentPoints.size > 1) {
                            val newAnnotation = Annotation.FreehandPen(
                                id = java.util.UUID.randomUUID().toString(),
                                pageIndex = 0,
                                color = currentColor.value.toLong(),
                                points = currentPoints.toList(),
                                strokeWidth = currentStrokeWidth
                            )
                            onNewAnnotationCreated(newAnnotation)
                        }
                        currentPoints.clear()
                    }
                )
            }
    ) {
        // Draw committed annotations
        annotations.forEach { annotation ->
            when (annotation) {
                is Annotation.FreehandPen -> {
                    if (annotation.points.size > 1) {
                        val path = Path().apply {
                            moveTo(annotation.points.first().x, annotation.points.first().y)
                            for (i in 1 until annotation.points.size) {
                                lineTo(annotation.points[i].x, annotation.points[i].y)
                            }
                        }
                        drawPath(
                            path = path,
                            color = Color(annotation.color.toULong()),
                            style = Stroke(
                                width = annotation.strokeWidth,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }
                else -> { /* Other annotations rendered by vector painter */ }
            }
        }

        // Draw live active stroke
        if (currentPoints.size > 1) {
            val livePath = Path().apply {
                moveTo(currentPoints.first().x, currentPoints.first().y)
                for (i in 1 until currentPoints.size) {
                    lineTo(currentPoints[i].x, currentPoints[i].y)
                }
            }
            drawPath(
                path = livePath,
                color = currentColor,
                style = Stroke(
                    width = currentStrokeWidth,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/octopdf/app/ui/MainViewModel.kt',
    language: 'kotlin',
    description: 'Main ViewModel coordinating multi-document tabs, split-screen state, undo/redo, and SAF operations.',
    content: `package com.octopdf.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.octopdf.app.data.model.DocumentTab
import com.octopdf.app.data.model.ReadingMode
import com.octopdf.app.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class MainUiState(
    val openTabs: List<DocumentTab> = emptyList(),
    val activeTabId: String? = null,
    val splitSecondaryTabId: String? = null,
    val isSplitScreenActive: Boolean = false,
    val unsavedTabToClose: DocumentTab? = null,
    val isLoading: Boolean = false
)

class MainViewModel(
    private val repository: PdfRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun openDocument(uri: Uri, title: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val existingTab = _uiState.value.openTabs.find { it.uri == uri }
            if (existingTab != null) {
                _uiState.update { it.copy(activeTabId = existingTab.id, isLoading = false) }
                return@launch
            }

            val newTab = DocumentTab(
                id = UUID.randomUUID().toString(),
                uri = uri,
                title = title,
                pageCount = 1 // Loaded via PdfEngine in background
            )

            _uiState.update { state ->
                state.copy(
                    openTabs = state.openTabs + newTab,
                    activeTabId = newTab.id,
                    isLoading = false
                )
            }
            repository.recordDocumentOpen(uri, title, newTab.pageCount)
        }
    }

    fun selectTab(tabId: String) {
        _uiState.update { it.copy(activeTabId = tabId) }
    }

    fun requestCloseTab(tab: DocumentTab) {
        if (tab.isModified) {
            _uiState.update { it.copy(unsavedTabToClose = tab) }
        } else {
            forceCloseTab(tab.id)
        }
    }

    fun forceCloseTab(tabId: String) {
        _uiState.update { state ->
            val remaining = state.openTabs.filterNot { it.id == tabId }
            val nextActive = if (state.activeTabId == tabId) remaining.firstOrNull()?.id else state.activeTabId
            state.copy(
                openTabs = remaining,
                activeTabId = nextActive,
                unsavedTabToClose = null
            )
        }
    }

    fun toggleSplitScreen(secondaryTabId: String? = null) {
        _uiState.update { state ->
            val isNowActive = !state.isSplitScreenActive
            val secondary = secondaryTabId 
                ?: state.openTabs.firstOrNull { it.id != state.activeTabId }?.id
            state.copy(
                isSplitScreenActive = isNowActive && secondary != null,
                splitSecondaryTabId = if (isNowActive) secondary else null
            )
        }
    }

    fun swapSplitPanes() {
        _uiState.update { state ->
            state.copy(
                activeTabId = state.splitSecondaryTabId,
                splitSecondaryTabId = state.activeTabId
            )
        }
    }

    fun setReadingMode(mode: ReadingMode) {
        _uiState.update { state ->
            val updated = state.openTabs.map { tab ->
                if (tab.id == state.activeTabId) tab.copy(readingMode = mode) else tab
            }
            state.copy(openTabs = updated)
        }
    }
}
`
  },
  {
    path: 'app/src/test/java/com/octopdf/app/TabManagerTest.kt',
    language: 'kotlin',
    description: 'Unit test verifying multi-document tab state, selection, and unsaved changes confirmation.',
    content: `package com.octopdf.app

import android.net.Uri
import com.google.common.truth.Truth.assertThat
import com.octopdf.app.data.model.DocumentTab
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import java.util.UUID

@RunWith(JUnit4::class)
class TabManagerTest {

    @Test
    fun addTab_increasesTabCount_andSelectsNewTab() {
        val initialTabs = listOf<DocumentTab>()
        val newTab = DocumentTab(
            id = UUID.randomUUID().toString(),
            uri = Uri.parse("content://docs/sample.pdf"),
            title = "sample.pdf"
        )

        val updatedTabs = initialTabs + newTab

        assertThat(updatedTabs).hasSize(1)
        assertThat(updatedTabs.first().title).isEqualTo("sample.pdf")
    }

    @Test
    fun closeModifiedTab_flagsUnsavedChanges() {
        val tab = DocumentTab(
            id = "test-tab-1",
            uri = Uri.parse("content://docs/contract.pdf"),
            title = "contract.pdf",
            isModified = true
        )

        val requiresConfirmation = tab.isModified
        assertThat(requiresConfirmation).isTrue()
    }
}
`
  },
  {
    path: 'app/src/test/java/com/octopdf/app/PdfRepositoryTest.kt',
    language: 'kotlin',
    description: 'Unit test for recent document recording and bookmarks.',
    content: `package com.octopdf.app

import com.google.common.truth.Truth.assertThat
import com.octopdf.app.data.db.RecentDocumentEntity
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class PdfRepositoryTest {

    @Test
    fun readingProgressUpdate_persistsAccuratePageIndex() {
        val initialEntity = RecentDocumentEntity(
            uriString = "content://docs/octopdf.pdf",
            title = "octopdf.pdf",
            totalPages = 12,
            lastReadPage = 0,
            lastAccessTime = 1000L
        )

        val updatedEntity = initialEntity.copy(lastReadPage = 4, lastAccessTime = 2000L)

        assertThat(updatedEntity.lastReadPage).isEqualTo(4)
        assertThat(updatedEntity.lastAccessTime).isGreaterThan(initialEntity.lastAccessTime)
    }
}
`
  },
  {
    path: 'app/src/androidTest/java/com/octopdf/app/SplitScreenUiTest.kt',
    language: 'kotlin',
    description: 'Android Compose UI test verifying dual-pane split-screen rendering and swap operation.',
    content: `package com.octopdf.app

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.performClick
import com.octopdf.app.data.model.DocumentTab
import com.octopdf.app.ui.split.SplitScreenContainer
import org.junit.Rule
import org.junit.Test

class SplitScreenUiTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun splitScreen_displaysBothPanes_andAllowsSwap() {
        var swapped = false

        val tab1 = DocumentTab(id = "1", uri = android.net.Uri.EMPTY, title = "Doc A")
        val tab2 = DocumentTab(id = "2", uri = android.net.Uri.EMPTY, title = "Doc B")

        composeTestRule.setContent {
            SplitScreenContainer(
                primaryTab = tab1,
                secondaryTab = tab2,
                isSplitActive = true,
                onSwapPanes = { swapped = true },
                primaryContent = { /* Left pane */ },
                secondaryContent = { /* Right pane */ }
            )
        }

        // Click the floating swap action button
        composeTestRule.onNodeWithContentDescription("Swap panes").performClick()
        assert(swapped)
    }
}
`
  },
  {
    path: '.gitignore',
    language: 'text',
    description: 'Standard Android gitignore for Gradle, build artifacts, and local configurations.',
    content: `*.iml
.gradle
/local.properties
/.idea/caches
/.idea/libraries
/.idea/modules.xml
/.idea/workspace.xml
/.idea/navEditor.xml
/.idea/assetWizardSettings.xml
.DS_Store
/build
/captures
.externalNativeBuild
.cxx
local.properties
`
  },
  {
    path: 'LICENSE',
    language: 'text',
    description: 'Apache License 2.0 ensuring safe enterprise compliance without AGPL copyleft contamination.',
    content: `                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION
   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
`
  }
];
