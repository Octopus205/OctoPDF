import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../data/androidProjectFiles';

export async function downloadAndroidProjectZip(): Promise<void> {
  const zip = new JSZip();

  // Root project folder
  const rootFolder = zip.folder('OctoPDF');

  if (!rootFolder) {
    throw new Error('Could not create zip folder');
  }

  // Add all Android files
  for (const file of ANDROID_PROJECT_FILES) {
    rootFolder.file(file.path, file.content);
  }

  // Add additional project standard files
  rootFolder.file(
    'README.md',
    `# OctoPDF — Offline Android PDF Viewer & Editor

Production-grade, fully offline PDF viewer and editor built with:
- **Language**: Kotlin 2.1.0 & Gradle Kotlin DSL
- **UI Framework**: Jetpack Compose (BOM 2024.12.01) with Material 3 Adaptive Layouts
- **PDF Engine**: PdfiumAndroid & Apache PDFBox-Android (100% Apache 2.0 license)
- **Target SDK**: 35 (minSdk 26)
- **Supported ABIs**: armeabi-v7a (32-bit ARM) and arm64-v8a (64-bit ARM)
- **Zero Internet Requirement**: Completely offline air-gapped security without \`android.permission.INTERNET\`
- **Multi-Document Tabs & Split Screen**: Full concurrent multi-file viewing and dual-pane comparison
- **Full Arabic / RTL Support**: Localized strings in \`values-ar\`

## How to Run in Android Studio
1. Open Android Studio (Ladybug / Koala or later).
2. Select **File > Open...** and choose this \`OctoPDF\` folder.
3. Allow Gradle to sync.
4. Select an Android emulator or device running Android 8.0+ (API 26+) and click **Run**.
`
  );

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'OctoPDF-Android-Project.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
