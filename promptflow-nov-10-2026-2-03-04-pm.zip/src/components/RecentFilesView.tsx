import React, { useRef } from 'react';
import { 
  Clock, 
  Star, 
  FileUp, 
  Trash2, 
  FolderOpen, 
  FileText, 
  ShieldCheck, 
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { PdfDocument, AppLanguage } from '../types/pdf';
import { TRANSLATIONS } from '../data/translations';

interface RecentFilesViewProps {
  documents: PdfDocument[];
  onOpenDoc: (docId: string) => void;
  onToggleFavorite: (docId: string) => void;
  onDeleteRecent: (docId: string) => void;
  onImportCustomPdf: (file: File) => void;
  lang: AppLanguage;
}

export const RecentFilesView: React.FC<RecentFilesViewProps> = ({
  documents,
  onOpenDoc,
  onToggleFavorite,
  onDeleteRecent,
  onImportCustomPdf,
  lang,
}) => {
  const t = TRANSLATIONS[lang];
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImportCustomPdf(e.target.files[0]);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 p-8 max-w-6xl mx-auto space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-rose-500 font-bold text-xs uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>{t.offlineNotice}</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-100">{t.recentFiles}</h2>
          <p className="text-xs text-slate-400">
            Storage Access Framework (SAF) & Room Database Persistent Vault
          </p>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="application/pdf"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-sm font-semibold rounded-xl transition shadow-lg shadow-rose-950/40"
          >
            <FileUp className="w-4 h-4" />
            <span>{t.openFile}</span>
          </button>
        </div>
      </div>

      {/* Grid of Files */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {documents.map((doc) => (
          <div
            key={doc.id}
            onClick={() => onOpenDoc(doc.id)}
            className="group relative bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 flex flex-col justify-between gap-4 cursor-pointer hover:shadow-xl transition"
          >
            {/* Top row */}
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-rose-500 group-hover:scale-110 transition">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-slate-100 line-clamp-1 group-hover:text-rose-400 transition">
                    {doc.name}
                  </h3>
                  <div className="text-[11px] text-slate-400">
                    {formatSize(doc.sizeBytes)} • {doc.pages.length} {t.page}s
                  </div>
                </div>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleFavorite(doc.id);
                }}
                className={`p-1.5 rounded-lg transition ${
                  doc.isFavorite ? 'text-amber-400 bg-amber-400/10' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                <Star className={`w-4 h-4 ${doc.isFavorite ? 'fill-amber-400' : ''}`} />
              </button>
            </div>

            {/* Reading progress badge */}
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs">
              <span className="text-slate-400">Reading Progress:</span>
              <span className="font-semibold text-rose-400">
                Page {doc.lastReadPage + 1} of {doc.pages.length}
              </span>
            </div>

            {/* Bottom metadata & delete */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Recently opened
              </span>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteRecent(doc.id);
                }}
                className="p-1 hover:text-rose-400 rounded transition"
                title="Remove from recents"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
