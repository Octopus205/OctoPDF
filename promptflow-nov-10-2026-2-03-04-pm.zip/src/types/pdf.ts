export type ReadingMode = 'light' | 'sepia' | 'night';

export type AnnotationType = 
  | 'highlight' 
  | 'underline' 
  | 'strikethrough' 
  | 'pen' 
  | 'note' 
  | 'rect' 
  | 'ellipse' 
  | 'arrow' 
  | 'signature'
  | 'stamp';

export interface Point {
  x: number;
  y: number;
}

export interface BaseAnnotation {
  id: string;
  pageIndex: number;
  type: AnnotationType;
  color: string;
  createdAt: number;
}

export interface DrawingAnnotation extends BaseAnnotation {
  type: 'pen' | 'highlight';
  points: Point[];
  strokeWidth: number;
  opacity: number;
}

export interface TextMarkupAnnotation extends BaseAnnotation {
  type: 'underline' | 'strikethrough';
  rect: { x: number; y: number; width: number; height: number };
}

export interface ShapeAnnotation extends BaseAnnotation {
  type: 'rect' | 'ellipse' | 'arrow';
  start: Point;
  end: Point;
  strokeWidth: number;
  fillColor?: string;
}

export interface NoteAnnotation extends BaseAnnotation {
  type: 'note';
  position: Point;
  text: string;
  author: string;
}

export interface SignatureAnnotation extends BaseAnnotation {
  type: 'signature' | 'stamp';
  position: Point;
  width: number;
  height: number;
  dataUrl: string;
}

export type Annotation = 
  | DrawingAnnotation 
  | TextMarkupAnnotation 
  | ShapeAnnotation 
  | NoteAnnotation 
  | SignatureAnnotation;

export interface PdfPage {
  index: number;
  title: string;
  rotation: number; // 0, 90, 180, 270
  content: string[]; // text paragraphs
  annotations: Annotation[];
}

export interface Bookmark {
  id: string;
  pageIndex: number;
  title: string;
  createdAt: number;
}

export interface PdfDocument {
  id: string;
  name: string;
  sizeBytes: number;
  totalPages: number;
  lastReadPage: number;
  lastModified: number;
  isFavorite: boolean;
  isPasswordProtected: boolean;
  password?: string;
  isModified: boolean;
  pages: PdfPage[];
  bookmarks: Bookmark[];
}

export type ActiveTool = 
  | 'select' 
  | 'pen' 
  | 'highlight' 
  | 'underline' 
  | 'strikethrough' 
  | 'rect' 
  | 'ellipse' 
  | 'arrow' 
  | 'note' 
  | 'signature' 
  | 'eraser';

export type DeviceMode = 'tablet' | 'phone';
export type AppLanguage = 'en' | 'ar';
export type ActiveView = 'viewer' | 'split' | 'tools' | 'android-code' | 'recent-files';
