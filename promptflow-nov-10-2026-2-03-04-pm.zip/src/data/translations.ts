export interface Translations {
  appName: string;
  tabs: string;
  splitScreen: string;
  tools: string;
  codebase: string;
  recentFiles: string;
  openFile: string;
  save: string;
  saveAsCopy: string;
  savedSuccessfully: string;
  unsavedChangesTitle: string;
  unsavedChangesMessage: string;
  discard: string;
  cancel: string;
  page: string;
  of: string;
  zoom: string;
  fitWidth: string;
  fitPage: string;
  lightMode: string;
  sepiaMode: string;
  nightMode: string;
  searchPlaceholder: string;
  searchResults: string;
  noResults: string;
  bookmarks: string;
  addBookmark: string;
  removeBookmark: string;
  thumbnails: string;
  pageManager: string;
  rotateClockwise: string;
  rotateCounterClockwise: string;
  deletePage: string;
  duplicatePage: string;
  moveUp: string;
  moveDown: string;
  close: string;
  splitLeft: string;
  splitRight: string;
  swapPanes: string;
  singleView: string;
  dualView: string;
  // Tools
  mergeTitle: string;
  mergeDesc: string;
  splitTitle: string;
  splitDesc: string;
  extractTitle: string;
  extractDesc: string;
  passwordTitle: string;
  passwordDesc: string;
  apply: string;
  // Annotations
  selectTool: string;
  penTool: string;
  highlightTool: string;
  underlineTool: string;
  strikethroughTool: string;
  rectTool: string;
  ellipseTool: string;
  arrowTool: string;
  noteTool: string;
  signatureTool: string;
  clearSignature: string;
  signHere: string;
  insertSignature: string;
  undo: string;
  redo: string;
  color: string;
  strokeWidth: string;
  // Adaptive
  deviceMode: string;
  tabletMode: string;
  phoneMode: string;
  downloadAndroidZip: string;
  architectureGuide: string;
  permissionsTitle: string;
  offlineNotice: string;
}

export const TRANSLATIONS: Record<'en' | 'ar', Translations> = {
  en: {
    appName: 'OctoPDF',
    tabs: 'Documents',
    splitScreen: 'Split View',
    tools: 'PDF Tools',
    codebase: 'Android Project & Code',
    recentFiles: 'Recent Files',
    openFile: 'Open Document',
    save: 'Save',
    saveAsCopy: 'Save as Copy',
    savedSuccessfully: 'Saved successfully',
    unsavedChangesTitle: 'Unsaved Changes',
    unsavedChangesMessage: 'This document has unsaved annotations or page changes. Would you like to save before closing?',
    discard: 'Discard',
    cancel: 'Cancel',
    page: 'Page',
    of: 'of',
    zoom: 'Zoom',
    fitWidth: 'Fit Width',
    fitPage: 'Fit Page',
    lightMode: 'Light Mode',
    sepiaMode: 'Sepia Mode',
    nightMode: 'Night Mode',
    searchPlaceholder: 'Search document text...',
    searchResults: 'Matches found',
    noResults: 'No matches found',
    bookmarks: 'Bookmarks',
    addBookmark: 'Bookmark Page',
    removeBookmark: 'Remove Bookmark',
    thumbnails: 'Thumbnails',
    pageManager: 'Page Manager',
    rotateClockwise: 'Rotate 90° CW',
    rotateCounterClockwise: 'Rotate 90° CCW',
    deletePage: 'Delete Page',
    duplicatePage: 'Duplicate Page',
    moveUp: 'Move Up',
    moveDown: 'Move Down',
    close: 'Close',
    splitLeft: 'Left Pane',
    splitRight: 'Right Pane',
    swapPanes: 'Swap Panes',
    singleView: 'Single Pane',
    dualView: 'Split Screen (Dual)',
    mergeTitle: 'Merge PDF Documents',
    mergeDesc: 'Combine multiple PDF documents into one continuous file',
    splitTitle: 'Split PDF Document',
    splitDesc: 'Divide this document into separate files by page range',
    extractTitle: 'Extract Pages',
    extractDesc: 'Export specific pages into a standalone PDF file',
    passwordTitle: 'Password Protection',
    passwordDesc: 'Set or remove 128-bit AES password encryption',
    apply: 'Apply & Generate',
    selectTool: 'Select',
    penTool: 'Freehand Pen',
    highlightTool: 'Highlighter',
    underlineTool: 'Underline',
    strikethroughTool: 'Strikethrough',
    rectTool: 'Rectangle',
    ellipseTool: 'Ellipse',
    arrowTool: 'Arrow',
    noteTool: 'Sticky Note',
    signatureTool: 'Digital Signature',
    clearSignature: 'Clear Signature',
    signHere: 'Sign here with finger or stylus',
    insertSignature: 'Insert Signature',
    undo: 'Undo',
    redo: 'Redo',
    color: 'Color',
    strokeWidth: 'Stroke Thickness',
    deviceMode: 'Device Layout',
    tabletMode: 'Tablet (Nav Rail)',
    phoneMode: 'Phone (Bottom Bar)',
    downloadAndroidZip: 'Download Android Studio Project (.ZIP)',
    architectureGuide: 'Engine & Licensing Guide',
    permissionsTitle: 'Android Permissions Matrix',
    offlineNotice: '100% Offline — No Internet Permission Required',
  },
  ar: {
    appName: 'أوكتو بي دي إف (OctoPDF)',
    tabs: 'المستندات',
    splitScreen: 'شاشة منقسمة',
    tools: 'أدوات PDF',
    codebase: 'مشروع أندرويد والكود المصدري',
    recentFiles: 'الملفات الأخيرة',
    openFile: 'فتح مستند',
    save: 'حفظ',
    saveAsCopy: 'حفظ كنسخة جديدة',
    savedSuccessfully: 'تم الحفظ بنجاح',
    unsavedChangesTitle: 'تغييرات غير محفوظة',
    unsavedChangesMessage: 'يحتوي هذا المستند على تدوينات أو تعديلات غير محفوظة. هل ترغب في حفظها قبل الإغلاق؟',
    discard: 'تجاهل التغييرات',
    cancel: 'إلغاء',
    page: 'صفحة',
    of: 'من',
    zoom: 'التكبير',
    fitWidth: 'ملاءمة العرض',
    fitPage: 'ملاءمة الصفحة',
    lightMode: 'الوضع الفاتح',
    sepiaMode: 'وضع القراءة الدافئ (Sepia)',
    nightMode: 'الوضع الليلي (Night)',
    searchPlaceholder: 'ابحث في محتوى المستند...',
    searchResults: 'نتائج البحث',
    noResults: 'لا توجد نتائج مطابقة',
    bookmarks: 'الإشارات المرجعية',
    addBookmark: 'حفظ إشارة مرجعية',
    removeBookmark: 'حذف الإشارة المرجعية',
    thumbnails: 'المصغرات',
    pageManager: 'إدارة الصفحات',
    rotateClockwise: 'تدوير 90° يميناً',
    rotateCounterClockwise: 'تدوير 90° يساراً',
    deletePage: 'حذف الصفحة',
    duplicatePage: 'تكرار الصفحة',
    moveUp: 'تحريك لأعلى',
    moveDown: 'تحريك لأسفل',
    close: 'إغلاق',
    splitLeft: 'المستند الأيمن',
    splitRight: 'المستند الأيسر',
    swapPanes: 'تبديل اللوحتين',
    singleView: 'شاشة فردية',
    dualView: 'عرض مزدوج (شاشة مقسمة)',
    mergeTitle: 'دمج ملفات PDF',
    mergeDesc: 'دمج عدة مستندات في ملف واحد متصل',
    splitTitle: 'تقسيم ملف PDF',
    splitDesc: 'تجزئة المستند إلى ملفات منفصلة حسب نطاق الصفحات',
    extractTitle: 'استخراج صفحات',
    extractDesc: 'تصدير صفحات محددة في ملف PDF مستقل',
    passwordTitle: 'حماية بكلمة مرور',
    passwordDesc: 'تعيين أو إزالة تشفير AES بكلمة مرور للملف',
    apply: 'تطبيق وتوليد الملف',
    selectTool: 'تحديد وتصفح',
    penTool: 'قلم حر',
    highlightTool: 'تظليل فسفوري',
    underlineTool: 'خط سفلي',
    strikethroughTool: 'شطب النص',
    rectTool: 'مستطيل',
    ellipseTool: 'شكل بيضاوي',
    arrowTool: 'سهم توجيهي',
    noteTool: 'ملاحظة لاصقة',
    signatureTool: 'توقيع رقمي',
    clearSignature: 'مسح التوقيع',
    signHere: 'وقع هنا بإصبعك أو القلم الذكي',
    insertSignature: 'إدراج التوقيع في الصفحة',
    undo: 'تراجع',
    redo: 'إعادة',
    color: 'اللون',
    strokeWidth: 'سُمك الخط',
    deviceMode: 'تخطيط الجهاز',
    tabletMode: 'جهاز لوحي (شريط جانبي)',
    phoneMode: 'هاتف ذكي (شريط سفلي)',
    downloadAndroidZip: 'تحميل مشروع أندرويد ستوديو (.ZIP)',
    architectureGuide: 'دليل المحركات والتراخيص',
    permissionsTitle: 'جدول أذونات أندرويد',
    offlineNotice: 'يعمل 100% بدون إنترنت — لا يتطلب صلاحية INTERNET',
  }
};
