import React from 'react';
import { AlertTriangle, Save, Download, Trash2, X } from 'lucide-react';
import { TRANSLATIONS } from '../data/translations';
import { AppLanguage, PdfDocument } from '../types/pdf';

interface UnsavedChangesModalProps {
  isOpen: boolean;
  doc: PdfDocument | null;
  onSave: () => void;
  onSaveAsCopy: () => void;
  onDiscard: () => void;
  onCancel: () => void;
  lang: AppLanguage;
}

export const UnsavedChangesModal: React.FC<UnsavedChangesModalProps> = ({
  isOpen,
  doc,
  onSave,
  onSaveAsCopy,
  onDiscard,
  onCancel,
  lang,
}) => {
  if (!isOpen || !doc) return null;
  const t = TRANSLATIONS[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-lg text-slate-100">{t.unsavedChangesTitle}</h3>
          </div>
          <button 
            onClick={onCancel}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300 leading-relaxed">
            {t.unsavedChangesMessage}
          </p>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center gap-3">
            <span className="text-xl">📄</span>
            <div className="truncate">
              <div className="text-xs font-semibold text-slate-200 truncate">{doc.name}</div>
              <div className="text-[11px] text-rose-400">Modified • Unsaved changes present</div>
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-950/50 border-t border-slate-800 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <button
              onClick={onSave}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium bg-rose-600 hover:bg-rose-500 text-white rounded-xl transition shadow-lg shadow-rose-900/30"
            >
              <Save className="w-4 h-4" />
              {t.save}
            </button>
            <button
              onClick={onSaveAsCopy}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition"
            >
              <Download className="w-4 h-4" />
              {t.saveAsCopy}
            </button>
          </div>
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={onDiscard}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-rose-400 hover:bg-rose-950/40 rounded-lg transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              {t.discard}
            </button>
            <button
              onClick={onCancel}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded-lg transition"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
