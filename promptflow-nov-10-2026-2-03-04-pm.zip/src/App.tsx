import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Columns2, 
  Layers, 
  FolderClock, 
  Code2, 
  Globe, 
  Tablet, 
  Smartphone, 
  ShieldCheck, 
  Sparkles,
  Download
} from 'lucide-react';
import { 
  PdfDocument, 
  ActiveView, 
  DeviceMode, 
  AppLanguage 
} from './types/pdf';
import { INITIAL_DOCUMENTS } from './data/sampleDocs';
import { TRANSLATIONS } from './data/translations';
import { TabBar } from './components/TabBar';
import { PdfViewerPane } from './components/PdfViewerPane';
import { SplitScreenContainer } from './components/SplitScreenContainer';
import { RecentFilesView } from './components/RecentFilesView';
import { PdfToolsModal } from './components/PdfToolsModal';
import { AndroidCodeExport } from './components/AndroidCodeExport';
import { UnsavedChangesModal } from './components/UnsavedChangesModal';
import { exportDocumentToPdf } from './utils/pdfGenerator';
import { downloadAndroidProjectZip } from './utils/zipExporter';

export default function App() {
  // Persistence for tabs & documents
  const [documents, setDocuments] = useState<PdfDocument[]>(() => {
    const saved = localStorage.getItem('octopdf_docs');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved docs', e);
      }
    }
    return INITIAL_DOCUMENTS;
  });

  const [activeTabId, setActiveTabId] = useState<string>(() => {
    return documents[0]?.id || 'doc-octopdf-guide';
  });

  const [splitSecondaryDocId, setSplitSecondaryDocId] = useState<string>(() => {
    return documents[1]?.id || documents[0]?.id;
  });

  const [activeView, setActiveView] = useState<ActiveView>('viewer');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('tablet');
  const [language, setLanguage] = useState<AppLanguage>('en');

  // Modal states
  const [isToolsModalOpen, setIsToolsModalOpen] = useState(false);
  const [tabPendingClose, setTabPendingClose] = useState<PdfDocument | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('octopdf_docs', JSON.stringify(documents));
  }, [documents]);

  const activeDoc = documents.find((d) => d.id === activeTabId) || documents[0];
  const t = TRANSLATIONS[language];

  // Document updates handler
  const handleUpdateDocument = (updatedDoc: PdfDocument) => {
    setDocuments((prev) =>
      prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d))
    );
  };

  const handleSaveDocument = (docToSave: PdfDocument) => {
    const saved = { ...docToSave, isModified: false, lastModified: Date.now() };
    handleUpdateDocument(saved);
  };

  // Tab Close Handler
  const handleRequestCloseTab = (docToClose: PdfDocument) => {
    if (docToClose.isModified) {
      setTabPendingClose(docToClose);
    } else {
      forceCloseTab(docToClose.id);
    }
  };

  const forceCloseTab = (docId: string) => {
    setDocuments((prev) => {
      const remaining = prev.filter((d) => d.id !== docId);
      if (remaining.length === 0) {
        // Always maintain at least one document
        return INITIAL_DOCUMENTS.slice(0, 1);
      }
      if (activeTabId === docId) {
        setActiveTabId(remaining[0].id);
      }
      return remaining;
    });
    setTabPendingClose(null);
  };

  const handleImportCustomPdf = (file: File) => {
    const newDoc: PdfDocument = {
      id: `doc-${Date.now()}`,
      name: file.name,
      sizeBytes: file.size,
      totalPages: 3,
      lastReadPage: 0,
      lastModified: Date.now(),
      isFavorite: false,
      isPasswordProtected: false,
      isModified: false,
      bookmarks: [],
      pages: [
        {
          index: 0,
          title: 'Document Preview',
          rotation: 0,
          annotations: [],
          content: [
            `# Imported Document: ${file.name}`,
            `Loaded via Storage Access Framework (SAF) URI content://${file.name}`,
            '• Offline Security: Read directly in sandboxed local memory without uploading to cloud servers.',
            '• Annotations Ready: Use the freehand pen, highlighter, or signature pad to mark up this file.'
          ]
        },
        {
          index: 1,
          title: 'Contract Terms & Notes',
          rotation: 0,
          annotations: [],
          content: [
            '# Section 2: Specifications & Compliance',
            'Full compliance with Android 15 edge-to-edge guidelines and Jetpack Compose BOM.',
            'Offline verification confirmed: android.permission.INTERNET is completely absent.'
          ]
        },
        {
          index: 2,
          title: 'Approval & Signatures',
          rotation: 0,
          annotations: [],
          content: [
            '# Section 3: Signatures',
            'Insert digital signatures with touch or stylus.',
            'Export to disk via "Save as Copy" whenever ready.'
          ]
        }
      ]
    };

    setDocuments((prev) => [newDoc, ...prev]);
    setActiveTabId(newDoc.id);
    setActiveView('viewer');
  };

  return (
    <div 
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="flex h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100"
    >
      {/* 
        TABLET NAVIGATION RAIL (Left in LTR, Right in RTL)
        Per Section 4: "The tablet layout uses a navigation rail or side panel for file lists and thumbnails."
      */}
      {deviceMode === 'tablet' && (
        <aside className="w-16 border-e border-slate-800 bg-slate-900 flex flex-col items-center justify-between py-4 select-none shrink-0 z-30">
          {/* Top: App Brand Icon (Octopus on PDF page) */}
          <div className="flex flex-col items-center gap-6">
            <div 
              className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-rose-600 to-rose-700 flex items-center justify-center shadow-lg shadow-rose-950 p-2 cursor-pointer group"
              title="OctoPDF: Octopus on PDF Page"
              onClick={() => setActiveView('viewer')}
            >
              {/* Octopus icon representation */}
              <div className="relative text-white font-extrabold text-sm tracking-tighter flex items-center justify-center">
                <span className="text-lg">🐙</span>
              </div>
              <div className="absolute -bottom-1 -right-1 px-1 bg-white text-slate-950 font-black text-[8px] rounded">
                PDF
              </div>
            </div>

            {/* Navigation Destinations */}
            <nav className="flex flex-col items-center gap-2">
              <button
                onClick={() => setActiveView('viewer')}
                className={`p-3 rounded-2xl transition flex flex-col items-center gap-1 ${
                  activeView === 'viewer'
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-950'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={t.tabs}
              >
                <FileText className="w-5 h-5" />
              </button>

              <button
                onClick={() => setActiveView('split')}
                className={`p-3 rounded-2xl transition flex flex-col items-center gap-1 ${
                  activeView === 'split'
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-950'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={t.splitScreen}
              >
                <Columns2 className="w-5 h-5" />
              </button>

              <button
                onClick={() => setIsToolsModalOpen(true)}
                className="p-3 rounded-2xl text-slate-400 hover:text-white hover:bg-slate-800 transition flex flex-col items-center gap-1"
                title={t.tools}
              >
                <Layers className="w-5 h-5" />
              </button>

              <button
                onClick={() => setActiveView('recent-files')}
                className={`p-3 rounded-2xl transition flex flex-col items-center gap-1 ${
                  activeView === 'recent-files'
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-950'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={t.recentFiles}
              >
                <FolderClock className="w-5 h-5" />
              </button>

              <div className="w-8 h-px bg-slate-800 my-1" />

              <button
                onClick={() => setActiveView('android-code')}
                className={`p-3 rounded-2xl transition flex flex-col items-center gap-1 ${
                  activeView === 'android-code'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                    : 'text-emerald-400/80 hover:text-emerald-300 hover:bg-slate-800'
                }`}
                title="Android Source Code & Gradle Workspace"
              >
                <Code2 className="w-5 h-5" />
              </button>
            </nav>
          </div>

          {/* Bottom Settings & Adaptive Switchers */}
          <div className="flex flex-col items-center gap-2">
            {/* Arabic / English Toggle */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-xs font-bold text-rose-400 transition"
              title={language === 'en' ? 'Switch to العربية (RTL)' : 'Switch to English (LTR)'}
            >
              <Globe className="w-4 h-4" />
            </button>

            {/* Layout Switcher (Tablet vs Phone) */}
            <button
              onClick={() => setDeviceMode('phone')}
              className="p-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title={t.phoneMode}
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>
        </aside>
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden bg-slate-950">
        {/* Top App Header (Brand, Mode Switcher, Multi-Document TabBar) */}
        <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur select-none shrink-0">
          <div className="h-12 px-4 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {/* Phone Logo display */}
              {deviceMode === 'phone' && (
                <div 
                  className="flex items-center gap-2 cursor-pointer"
                  onClick={() => setActiveView('viewer')}
                >
                  <div className="w-7 h-7 rounded-lg bg-rose-600 flex items-center justify-center text-xs">
                    🐙
                  </div>
                  <span className="font-bold text-sm text-slate-100">OctoPDF</span>
                </div>
              )}

              {/* Offline Badge */}
              <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-full text-[10px] font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.offlineNotice}</span>
              </div>
            </div>

            {/* Right Header Controls */}
            <div className="flex items-center gap-2">
              {/* Quick Android Code button */}
              <button
                onClick={() => setActiveView('android-code')}
                className={`hidden md:flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-xl border transition ${
                  activeView === 'android-code'
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'bg-slate-800 border-slate-700 text-emerald-400 hover:bg-slate-700'
                }`}
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Android Studio Code</span>
              </button>

              {/* Language switcher */}
              <button
                onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
                className="px-2.5 py-1 rounded-lg bg-slate-800 text-xs font-semibold text-rose-300 hover:bg-slate-700 transition"
              >
                {language === 'en' ? 'العربية' : 'English'}
              </button>

              {/* Device Mode Toggle */}
              <button
                onClick={() => setDeviceMode(deviceMode === 'tablet' ? 'phone' : 'tablet')}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition"
                title={deviceMode === 'tablet' ? t.phoneMode : t.tabletMode}
              >
                {deviceMode === 'tablet' ? <Tablet className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Tab Bar (Only when in Viewer or Split screen mode) */}
          {(activeView === 'viewer' || activeView === 'split') && (
            <TabBar
              documents={documents}
              activeDocId={activeTabId}
              onSelectDoc={(id) => {
                setActiveTabId(id);
                if (activeView === 'split' && id === splitSecondaryDocId) {
                  // If clicking the doc already in right pane, keep left pane
                }
              }}
              onRequestCloseDoc={handleRequestCloseTab}
              onNewDoc={() => {
                handleImportCustomPdf(
                  new File([''], `Document_${documents.length + 1}.pdf`, { type: 'application/pdf' })
                );
              }}
              lang={language}
            />
          )}
        </header>

        {/* View Router */}
        <div className="flex-1 flex overflow-hidden">
          {activeView === 'viewer' && activeDoc && (
            <PdfViewerPane
              doc={activeDoc}
              onUpdateDoc={handleUpdateDocument}
              onSaveDoc={handleSaveDocument}
              lang={language}
            />
          )}

          {activeView === 'split' && (
            <SplitScreenContainer
              documents={documents}
              leftDocId={activeTabId}
              rightDocId={splitSecondaryDocId}
              onSelectLeftDoc={setActiveTabId}
              onSelectRightDoc={setSplitSecondaryDocId}
              onUpdateDoc={handleUpdateDocument}
              onSaveDoc={handleSaveDocument}
              onExitSplit={() => setActiveView('viewer')}
              lang={language}
            />
          )}

          {activeView === 'recent-files' && (
            <RecentFilesView
              documents={documents}
              onOpenDoc={(id) => {
                setActiveTabId(id);
                setActiveView('viewer');
              }}
              onToggleFavorite={(id) => {
                const doc = documents.find((d) => d.id === id);
                if (doc) {
                  handleUpdateDocument({ ...doc, isFavorite: !doc.isFavorite });
                }
              }}
              onDeleteRecent={(id) => {
                forceCloseTab(id);
              }}
              onImportCustomPdf={handleImportCustomPdf}
              lang={language}
            />
          )}

          {activeView === 'android-code' && (
            <AndroidCodeExport lang={language} />
          )}
        </div>

        {/* 
          PHONE BOTTOM NAVIGATION BAR (Visible when in Phone layout mode)
          Per Section 4: "Adaptive layouts... Phone bottom navigation / floating toolbar"
        */}
        {deviceMode === 'phone' && (
          <nav className="h-14 border-t border-slate-800 bg-slate-900/95 backdrop-blur px-6 flex items-center justify-around select-none shrink-0 z-30">
            <button
              onClick={() => setActiveView('viewer')}
              className={`flex flex-col items-center gap-1 ${
                activeView === 'viewer' ? 'text-rose-500 font-bold' : 'text-slate-400'
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-[10px]">{t.tabs}</span>
            </button>

            <button
              onClick={() => setActiveView('split')}
              className={`flex flex-col items-center gap-1 ${
                activeView === 'split' ? 'text-rose-500 font-bold' : 'text-slate-400'
              }`}
            >
              <Columns2 className="w-5 h-5" />
              <span className="text-[10px]">{t.splitScreen}</span>
            </button>

            <button
              onClick={() => setIsToolsModalOpen(true)}
              className="flex flex-col items-center gap-1 text-slate-400"
            >
              <Layers className="w-5 h-5" />
              <span className="text-[10px]">{t.tools}</span>
            </button>

            <button
              onClick={() => setActiveView('recent-files')}
              className={`flex flex-col items-center gap-1 ${
                activeView === 'recent-files' ? 'text-rose-500 font-bold' : 'text-slate-400'
              }`}
            >
              <FolderClock className="w-5 h-5" />
              <span className="text-[10px]">{t.recentFiles}</span>
            </button>

            <button
              onClick={() => setActiveView('android-code')}
              className={`flex flex-col items-center gap-1 ${
                activeView === 'android-code' ? 'text-emerald-400 font-bold' : 'text-slate-400'
              }`}
            >
              <Code2 className="w-5 h-5" />
              <span className="text-[10px]">Android</span>
            </button>
          </nav>
        )}
      </main>

      {/* PDF Tools Modal (Merge, Split, Extract, Password) */}
      <PdfToolsModal
        isOpen={isToolsModalOpen}
        onClose={() => setIsToolsModalOpen(false)}
        allDocs={documents}
        activeDoc={activeDoc}
        onUpdateDoc={handleUpdateDocument}
        lang={language}
      />

      {/* Unsaved Changes Confirmation Modal */}
      <UnsavedChangesModal
        isOpen={tabPendingClose !== null}
        doc={tabPendingClose}
        onSave={() => {
          if (tabPendingClose) {
            handleSaveDocument(tabPendingClose);
            forceCloseTab(tabPendingClose.id);
          }
        }}
        onSaveAsCopy={async () => {
          if (tabPendingClose) {
            await exportDocumentToPdf(tabPendingClose, '_SavedCopy');
            forceCloseTab(tabPendingClose.id);
          }
        }}
        onDiscard={() => {
          if (tabPendingClose) {
            forceCloseTab(tabPendingClose.id);
          }
        }}
        onCancel={() => setTabPendingClose(null)}
        lang={language}
      />
    </div>
  );
}
