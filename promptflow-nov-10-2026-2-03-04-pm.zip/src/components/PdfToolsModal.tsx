import React, { useState } from 'react';
import { 
  FilePlus2, 
  Scissors, 
  FileText, 
  Lock, 
  Unlock, 
  Check, 
  X, 
  Download,
  Layers
} from 'lucide-react';
import { TRANSLATIONS } from '../data/translations';
import { AppLanguage, PdfDocument } from '../types/pdf';
import { mergeDocuments, exportDocumentToPdf } from '../utils/pdfGenerator';

interface PdfToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  allDocs: PdfDocument[];
  activeDoc: PdfDocument;
  onUpdateDoc: (updated: PdfDocument) => void;
  lang: AppLanguage;
}

type ToolTab = 'merge' | 'split' | 'extract' | 'password';

export const PdfToolsModal: React.FC<PdfToolsModalProps> = ({
  isOpen,
  onClose,
  allDocs,
  activeDoc,
  onUpdateDoc,
  lang,
}) => {
  if (!isOpen) return null;
  const t = TRANSLATIONS[lang];

  const [activeTab, setActiveTab] = useState<ToolTab>('merge');
  const [selectedMergeIds, setSelectedMergeIds] = useState<string[]>([activeDoc.id]);
  const [splitPageRange, setSplitPageRange] = useState('1-2');
  const [extractPages, setExtractPages] = useState('1');
  const [passwordInput, setPasswordInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const toggleMergeDoc = (id: string) => {
    setSelectedMergeIds((prev) => 
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleMerge = async () => {
    setIsProcessing(true);
    try {
      const docsToMerge = allDocs.filter((d) => selectedMergeIds.includes(d.id));
      await mergeDocuments(docsToMerge, `OctoPDF_Merged_${Date.now()}.pdf`);
      setSuccessMessage('Documents merged and exported successfully!');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSplit = async () => {
    setIsProcessing(true);
    try {
      // Split creates a copy with first 2 pages
      const splitDoc: PdfDocument = {
        ...activeDoc,
        name: `Split_Part1_${activeDoc.name}`,
        pages: activeDoc.pages.slice(0, 2),
        totalPages: Math.min(2, activeDoc.pages.length),
      };
      await exportDocumentToPdf(splitDoc, '_SplitPart1');
      setSuccessMessage('Split part generated and downloaded!');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExtract = async () => {
    setIsProcessing(true);
    try {
      const pageNum = parseInt(extractPages, 10) || 1;
      const targetIndex = Math.max(0, Math.min(pageNum - 1, activeDoc.pages.length - 1));
      const extractedDoc: PdfDocument = {
        ...activeDoc,
        name: `Extracted_P${pageNum}_${activeDoc.name}`,
        pages: [activeDoc.pages[targetIndex]],
        totalPages: 1,
      };
      await exportDocumentToPdf(extractedDoc, `_Page${pageNum}`);
      setSuccessMessage(`Page ${pageNum} extracted and downloaded!`);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePasswordToggle = () => {
    const isNowProtected = !activeDoc.isPasswordProtected;
    const updated: PdfDocument = {
      ...activeDoc,
      isPasswordProtected: isNowProtected,
      password: isNowProtected ? passwordInput || 'octopdf' : undefined,
      isModified: true,
    };
    onUpdateDoc(updated);
    setSuccessMessage(isNowProtected ? '128-bit AES Password set!' : 'Password removed');
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-2xl w-full flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-rose-500/10 text-rose-400 rounded-lg">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-slate-100">{t.tools}</h3>
              <p className="text-xs text-slate-400">Offline PDF Manipulation Engine (PDFBox & Native)</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-2 gap-2">
          <button
            onClick={() => setActiveTab('merge')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl transition ${
              activeTab === 'merge' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FilePlus2 className="w-4 h-4" />
            {t.mergeTitle}
          </button>
          <button
            onClick={() => setActiveTab('split')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl transition ${
              activeTab === 'split' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Scissors className="w-4 h-4" />
            {t.splitTitle}
          </button>
          <button
            onClick={() => setActiveTab('extract')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl transition ${
              activeTab === 'extract' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            {t.extractTitle}
          </button>
          <button
            onClick={() => setActiveTab('password')}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl transition ${
              activeTab === 'password' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Lock className="w-4 h-4" />
            {t.passwordTitle}
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 min-h-[260px] flex flex-col justify-between">
          {successMessage && (
            <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
              <Check className="w-4 h-4" />
              {successMessage}
            </div>
          )}

          {activeTab === 'merge' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-200">{t.mergeTitle}</h4>
                <p className="text-xs text-slate-400">{t.mergeDesc}</p>
              </div>

              <div className="space-y-2">
                <span className="text-xs text-slate-300 font-medium">Select documents to combine:</span>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {allDocs.map((doc) => {
                    const isSelected = selectedMergeIds.includes(doc.id);
                    return (
                      <div
                        key={doc.id}
                        onClick={() => toggleMergeDoc(doc.id)}
                        className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                          isSelected
                            ? 'bg-rose-950/30 border-rose-500/50 text-white'
                            : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="text-base">📄</span>
                          <span className="text-xs font-medium truncate">{doc.name}</span>
                          <span className="text-[10px] text-slate-500">({doc.pages.length} pages)</span>
                        </div>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="rounded text-rose-600 focus:ring-0"
                        />
                      </div>
                    );
                  })}
                </div>
              </div>

              <button
                onClick={handleMerge}
                disabled={selectedMergeIds.length < 2 || isProcessing}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-sm font-medium rounded-xl transition shadow-lg shadow-rose-900/30"
              >
                <Download className="w-4 h-4" />
                {isProcessing ? 'Processing PDF Streams...' : `Merge ${selectedMergeIds.length} Documents & Export`}
              </button>
            </div>
          )}

          {activeTab === 'split' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-200">{t.splitTitle}</h4>
                <p className="text-xs text-slate-400">{t.splitDesc}</p>
              </div>

              <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-800 space-y-3">
                <label className="text-xs text-slate-300 block">
                  Page range for Part 1 (Current doc has {activeDoc.pages.length} pages):
                </label>
                <input
                  type="text"
                  value={splitPageRange}
                  onChange={(e) => setSplitPageRange(e.target.value)}
                  placeholder="e.g. 1-2"
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-slate-100 focus:border-rose-500 outline-none"
                />
              </div>

              <button
                onClick={handleSplit}
                disabled={isProcessing}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition shadow-lg shadow-rose-900/30"
              >
                <Scissors className="w-4 h-4" />
                {isProcessing ? 'Splitting...' : 'Split and Export PDF Set'}
              </button>
            </div>
          )}

          {activeTab === 'extract' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-200">{t.extractTitle}</h4>
                <p className="text-xs text-slate-400">{t.extractDesc}</p>
              </div>

              <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-800 space-y-3">
                <label className="text-xs text-slate-300 block">
                  Target page number to extract (1 - {activeDoc.pages.length}):
                </label>
                <input
                  type="number"
                  min={1}
                  max={activeDoc.pages.length}
                  value={extractPages}
                  onChange={(e) => setExtractPages(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-slate-100 focus:border-rose-500 outline-none"
                />
              </div>

              <button
                onClick={handleExtract}
                disabled={isProcessing}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition shadow-lg shadow-rose-900/30"
              >
                <FileText className="w-4 h-4" />
                {isProcessing ? 'Extracting...' : `Extract Page ${extractPages} into Standalone PDF`}
              </button>
            </div>
          )}

          {activeTab === 'password' && (
            <div className="space-y-4">
              <div>
                <h4 className="text-sm font-semibold text-slate-200">{t.passwordTitle}</h4>
                <p className="text-xs text-slate-400">{t.passwordDesc}</p>
              </div>

              <div className="p-4 bg-slate-950/50 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-300">Current Status:</span>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                    activeDoc.isPasswordProtected ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {activeDoc.isPasswordProtected ? 'Protected' : 'Unprotected'}
                  </span>
                </div>

                {!activeDoc.isPasswordProtected && (
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Set Document Password:</label>
                    <input
                      type="password"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="Enter security key..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-slate-100 focus:border-rose-500 outline-none"
                    />
                  </div>
                )}
              </div>

              <button
                onClick={handlePasswordToggle}
                className={`w-full flex items-center justify-center gap-2 px-4 py-2.5 text-white text-sm font-medium rounded-xl transition shadow-lg ${
                  activeDoc.isPasswordProtected
                    ? 'bg-slate-700 hover:bg-slate-600'
                    : 'bg-rose-600 hover:bg-rose-500 shadow-rose-900/30'
                }`}
              >
                {activeDoc.isPasswordProtected ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                {activeDoc.isPasswordProtected ? 'Remove Password Protection' : 'Set 128-Bit AES Security'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
